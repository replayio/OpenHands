import React, { useState } from 'react';
import { Printer, LocateFixed, Navigation } from 'lucide-react';
import { DirectionsForm } from './components/DirectionsForm';
import { DirectionsList } from './components/DirectionsList';
import { MapView } from './components/MapView';
import type { Location, Route } from './types';

function App() {
  const [route, setRoute] = useState<Route | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getDirections = async (from: Location, to: Location) => {
    setLoading(true);
    setError(null);
    
    try {
      // First get coordinates for locations using Nominatim
      const [fromCoords, toCoords] = await Promise.all([
        fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(from.address)}`)
          .then(res => res.json())
          .then(data => data[0]),
        fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(to.address)}`)
          .then(res => res.json())
          .then(data => data[0])
      ]);

      if (!fromCoords || !toCoords) {
        throw new Error('Could not find one or both locations');
      }

      // Get route using OSRM
      const response = await fetch(
        `https://router.project-osrm.org/route/v1/driving/${fromCoords.lon},${fromCoords.lat};${toCoords.lon},${toCoords.lat}?overview=full&steps=true&geometries=geojson`
      );
      const data = await response.json();

      if (data.code !== 'Ok') {
        throw new Error('Could not calculate route');
      }

      setRoute({
        from: { ...from, coordinates: [fromCoords.lon, fromCoords.lat] },
        to: { ...to, coordinates: [toCoords.lon, toCoords.lat] },
        distance: data.routes[0].distance,
        duration: data.routes[0].duration,
        steps: data.routes[0].legs[0].steps,
        geometry: data.routes[0].geometry
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-600 text-white shadow-lg print:hidden">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Navigation className="h-6 w-6" />
              <h1 className="text-xl font-bold">OpenStreetMap Directions</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <DirectionsForm onSubmit={getDirections} loading={loading} />
            
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                {error}
              </div>
            )}

            {route && (
              <div className="bg-white shadow rounded-lg p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-semibold">Directions</h2>
                  <button
                    onClick={handlePrint}
                    className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 print:hidden"
                  >
                    <Printer className="h-4 w-4" />
                    <span>Print</span>
                  </button>
                </div>
                <DirectionsList route={route} />
              </div>
            )}
          </div>

          <div className="print:hidden">
            <div className="bg-white shadow rounded-lg p-4 h-[600px]">
              <MapView route={route} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
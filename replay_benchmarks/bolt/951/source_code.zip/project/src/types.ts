export interface Location {
  address: string;
  coordinates?: [number, number]; // [longitude, latitude]
}

export interface Route {
  from: Location;
  to: Location;
  distance: number;
  duration: number;
  steps: Array<{
    distance: number;
    duration: number;
    geometry: any;
    maneuver: {
      location: [number, number];
      instruction: string;
    };
    mode: string;
    name: string;
  }>;
  geometry: {
    coordinates: Array<[number, number]>;
    type: string;
  };
}
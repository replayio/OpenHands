import React, { useEffect, useRef, useState } from 'react';
import type { Route } from '../types';

interface MapViewProps {
  route: Route | null;
}

export function MapView({ route }: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const [isMapReady, setIsMapReady] = useState(false);

  // Initialize Leaflet
  useEffect(() => {
    if (!mapRef.current || typeof window === 'undefined') return;

    let L: any;
    const loadMap = async () => {
      // Wait for Leaflet script to load
      if (!(window as any).L) {
        const script = document.createElement('script');
        script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
        script.integrity = 'sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=';
        script.crossOrigin = '';
        document.body.appendChild(script);

        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        link.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
        link.crossOrigin = '';
        document.head.appendChild(link);

        await new Promise<void>((resolve) => {
          script.onload = () => resolve();
        });
      }

      L = (window as any).L;
      
      if (!mapInstanceRef.current && mapRef.current) {
        const map = L.map(mapRef.current).setView([51.505, -0.09], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          attribution: '© OpenStreetMap contributors'
        }).addTo(map);
        mapInstanceRef.current = map;
        setIsMapReady(true);
      }
    };

    loadMap();

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
        setIsMapReady(false);
      }
    };
  }, []);

  // Update map when route changes
  useEffect(() => {
    if (!isMapReady || !mapInstanceRef.current || !route?.from.coordinates || !route?.to.coordinates) {
      return;
    }

    const L = (window as any).L;
    const map = mapInstanceRef.current;

    // Clear existing layers
    map.eachLayer((layer: any) => {
      if (layer instanceof L.Marker || layer instanceof L.Polyline) {
        map.removeLayer(layer);
      }
    });

    try {
      // Add markers
      const startPoint: [number, number] = [route.from.coordinates[1], route.from.coordinates[0]];
      const endPoint: [number, number] = [route.to.coordinates[1], route.to.coordinates[0]];

      const startMarker = L.marker(startPoint).addTo(map)
        .bindPopup('Start: ' + route.from.address);
      const endMarker = L.marker(endPoint).addTo(map)
        .bindPopup('End: ' + route.to.address);

      // Add route line if geometry exists
      let bounds;
      if (route.geometry?.coordinates?.length > 0) {
        const routeCoords = route.geometry.coordinates.map(coord => [coord[1], coord[0]]);
        const routeLine = L.polyline(routeCoords, {
          color: '#3b82f6',
          weight: 4,
          opacity: 0.8
        }).addTo(map);

        bounds = routeLine.getBounds();
      } else {
        bounds = L.latLngBounds([startPoint, endPoint]);
      }

      // Fit map to show all points
      if (bounds && bounds.isValid()) {
        map.fitBounds(bounds, {
          padding: [50, 50],
          maxZoom: 16
        });
      }
    } catch (error) {
      console.error('Error updating map:', error);
      // Reset to default view on error
      map.setView([51.505, -0.09], 13);
    }
  }, [route, isMapReady]);

  return <div ref={mapRef} className="w-full h-full" />;
}
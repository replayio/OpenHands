import React from 'react';
import type { Route } from '../types';

interface DirectionsListProps {
  route: Route;
}

export function DirectionsList({ route }: DirectionsListProps) {
  const formatDistance = (meters: number) => {
    return (meters / 1000).toFixed(1) + ' km';
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) {
      return `${hours} hr ${minutes} min`;
    }
    return `${minutes} min`;
  };

  return (
    <div className="space-y-4">
      <div className="border-b pb-4">
        <div className="text-sm text-gray-500">From</div>
        <div className="font-medium">{route.from.address}</div>
        <div className="text-sm text-gray-500 mt-2">To</div>
        <div className="font-medium">{route.to.address}</div>
        <div className="mt-4 flex space-x-4 text-sm text-gray-500">
          <div>Distance: {formatDistance(route.distance)}</div>
          <div>Duration: {formatDuration(route.duration)}</div>
        </div>
      </div>

      <ol className="space-y-4">
        {route.steps.map((step, index) => (
          <li key={index} className="flex space-x-4">
            <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-medium">
              {index + 1}
            </div>
            <div>
              <p className="text-gray-700">{step.maneuver.instruction}</p>
              <p className="text-sm text-gray-500">
                {formatDistance(step.distance)}
              </p>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}
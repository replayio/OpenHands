import { FunctionCallNode, ParserContext, ASTNode } from './types';
import { peek, consume } from './parserUtils';
import { parseExpression } from './parseExpression';

export function parseFunctionCall(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): FunctionCallNode {
  onStep('Function Call: Start', null);

  const identifier = peek(context);
  if (!identifier || identifier.type !== 'identifier') {
    throw new Error('Expected function name');
  }

  // Check if function exists
  if (!context.functions.has(identifier.value)) {
    throw new Error(`Undefined function: ${identifier.value}`);
  }

  const functionName = identifier.value;
  consume(context);

  onStep('Function Call: Name', { 
    type: 'functionCall', 
    callee: functionName, 
    arguments: [] 
  });

  // Expect opening parenthesis
  const openParen = peek(context);
  if (!openParen || openParen.type !== 'paren' || openParen.value !== '(') {
    throw new Error('Expected ( after function name');
  }
  consume(context);

  // Parse arguments
  const args: ASTNode[] = [];
  while (context.current < context.tokens.length) {
    const token = peek(context);
    if (!token) break;

    if (token.type === 'paren' && token.value === ')') {
      consume(context);
      break;
    }

    if (token.type === 'comma') {
      consume(context);
      continue;
    }

    const arg = parseExpression(context, onStep);
    args.push(arg);
    
    onStep('Function Call: Argument', { 
      type: 'functionCall', 
      callee: functionName, 
      arguments: [...args] 
    });
  }

  const node: FunctionCallNode = {
    type: 'functionCall',
    callee: functionName,
    arguments: args
  };

  onStep('Function Call: Complete', node);
  return node;
}
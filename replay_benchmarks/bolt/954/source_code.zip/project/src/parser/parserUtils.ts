import { Token, ParserContext, ParserState, Scope } from './types';

export function peek(context: ParserContext): Token | null {
  if (context.current >= context.tokens.length) return null;
  return context.tokens[context.current];
}

export function consume(context: ParserContext): Token | null {
  if (context.current >= context.tokens.length) return null;
  return context.tokens[context.current++];
}

export function createState(context: ParserContext, options: Partial<ParserState> = {}): ParserState {
  return {
    tokens: context.tokens,
    currentToken: context.current,
    ast: context.ast ? structuredClone(context.ast) : null,
    error: context.error || null,
    done: false,
    rule: context.currentRule,
    ...options
  };
}

export function isValidIdentifier(name: string): boolean {
  return /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name);
}

export function createScope(parent: Scope | null = null): Scope {
  return {
    variables: new Set<string>(),
    parent
  };
}

export function isVariableInScope(scope: Scope, name: string): boolean {
  if (scope.variables.has(name)) return true;
  if (scope.parent) return isVariableInScope(scope.parent, name);
  return false;
}

export function addVariableToScope(scope: Scope, name: string): void {
  scope.variables.add(name);
}

export function lookAhead(context: ParserContext, steps: number = 1): Token | null {
  if (context.current + steps >= context.tokens.length) return null;
  return context.tokens[context.current + steps];
}
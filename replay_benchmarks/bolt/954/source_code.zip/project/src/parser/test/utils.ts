import { Parser } from '../parser';
import { tokenize } from '../tokenizer';

export function parse(code: string): any {
  const tokens = tokenize(code);
  const parser = new Parser(tokens);
  let state = parser.step();
  
  while (!state.done && !state.error) {
    state = parser.step();
  }
  
  if (state.error) {
    throw new Error(state.error);
  }
  
  return state.ast;
}
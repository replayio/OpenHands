import { describe, test, expect } from 'vitest';
import { Parser } from '../parser';
import { tokenize } from '../tokenizer';
import { parse } from './utils';

describe('Basic Parsing', () => {
  test('parses a single number', () => {
    const ast = parse('42');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        { type: 'number', value: 42 }
      ]
    });
  });

  test('parses simple multiplication', () => {
    const ast = parse('2 * 3');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'multiplication',
        left: { type: 'number', value: 2 },
        right: { type: 'number', value: 3 }
      }]
    });
  });

  test('parses simple addition', () => {
    const ast = parse('1 + 2');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'addition',
        left: { type: 'number', value: 1 },
        right: { type: 'number', value: 2 }
      }]
    });
  });
});
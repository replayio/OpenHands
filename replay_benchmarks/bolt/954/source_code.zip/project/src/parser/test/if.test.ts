import { describe, test, expect } from 'vitest';
import { parse } from './utils';

describe('If Statements', () => {
  test('parses if statement with block', () => {
    const ast = parse('if 1 < 2 { print 3 }');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'if',
        condition: {
          type: 'comparison',
          operator: '<',
          left: { type: 'number', value: 1 },
          right: { type: 'number', value: 2 }
        },
        consequent: {
          type: 'block',
          statements: [
            { type: 'print', argument: { type: 'number', value: 3 } }
          ]
        }
      }]
    });
  });

  test('parses if with multiple statements in block', () => {
    const ast = parse('if 1 <= 2 { var x = 3; print x }');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'if',
        condition: {
          type: 'comparison',
          operator: '<=',
          left: { type: 'number', value: 1 },
          right: { type: 'number', value: 2 }
        },
        consequent: {
          type: 'block',
          statements: [
            {
              type: 'varDeclaration',
              name: 'x',
              initializer: { type: 'number', value: 3 }
            },
            {
              type: 'print',
              argument: { type: 'identifier', name: 'x' }
            }
          ]
        }
      }]
    });
  });

  test('parses nested if statements with blocks', () => {
    const ast = parse('if 1 < 2 { if 3 < 4 { print 5 } }');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'if',
        condition: {
          type: 'comparison',
          operator: '<',
          left: { type: 'number', value: 1 },
          right: { type: 'number', value: 2 }
        },
        consequent: {
          type: 'block',
          statements: [{
            type: 'if',
            condition: {
              type: 'comparison',
              operator: '<',
              left: { type: 'number', value: 3 },
              right: { type: 'number', value: 4 }
            },
            consequent: {
              type: 'block',
              statements: [
                { type: 'print', argument: { type: 'number', value: 5 } }
              ]
            }
          }]
        }
      }]
    });
  });

  test('throws on missing opening brace', () => {
    expect(() => parse('if 1 < 2 print 3 }')).toThrow('Expected opening brace {');
  });

  test('throws on missing closing brace', () => {
    expect(() => parse('if 1 < 2 { print 3')).toThrow('Expected closing brace }');
  });

  test('throws on empty block', () => {
    expect(() => parse('if 1 < 2 { }')).toThrow('Expected statement in if block');
  });
});
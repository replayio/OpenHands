import { describe, test, expect } from 'vitest';
import { Parser } from '../parser';
import { tokenize } from '../tokenizer';

describe('Parser Step-by-Step Functionality', () => {
  test('step-by-step parsing of print statement', () => {
    const tokens = tokenize('print 1 + 2');
    const parser = new Parser(tokens);
    
    // Initial state
    let state = parser.step();
    expect(state.done).toBe(false);
    expect(state.error).toBe(null);
    
    // Collect all states until done or error
    const states = [state];
    while (!state.done && !state.error) {
      state = parser.step();
      states.push(state);
    }
    
    // Final state should be successful
    expect(state.error).toBe(null);
    expect(state.done).toBe(true);
    
    // Final AST should be correct
    expect(state.ast).toEqual({
      type: 'program',
      statements: [{
        type: 'print',
        argument: {
          type: 'addition',
          left: { type: 'number', value: 1 },
          right: { type: 'number', value: 2 }
        }
      }]
    });
    
    // Each state should have required properties
    states.forEach(s => {
      expect(s).toHaveProperty('tokens');
      expect(s).toHaveProperty('currentToken');
      expect(s).toHaveProperty('ast');
      expect(s).toHaveProperty('error');
      expect(s).toHaveProperty('done');
    });
  });

  test('parser state progression for simple expression', () => {
    const tokens = tokenize('1 + 2');
    const parser = new Parser(tokens);
    
    let state = parser.step();
    const states = [state];
    
    // Collect all states until done or error
    while (!state.done && !state.error) {
      state = parser.step();
      states.push(state);
    }
    
    // Final state should be successful
    expect(state.error).toBe(null);
    expect(state.done).toBe(true);
    
    // Final AST should be correct
    expect(state.ast).toEqual({
      type: 'program',
      statements: [{
        type: 'addition',
        left: { type: 'number', value: 1 },
        right: { type: 'number', value: 2 }
      }]
    });
    
    // Each state should have required properties
    states.forEach(s => {
      expect(s).toHaveProperty('tokens');
      expect(s).toHaveProperty('currentToken');
      expect(s).toHaveProperty('ast');
      expect(s).toHaveProperty('error');
      expect(s).toHaveProperty('done');
    });
  });

  test('parser handles errors gracefully', () => {
    const tokens = tokenize('print');
    const parser = new Parser(tokens);
    
    let state = parser.step();
    const states = [state];
    
    // Collect states until done or error
    while (!state.done && !state.error) {
      state = parser.step();
      states.push(state);
    }
    
    // Should end with an error
    expect(state.error).toBeTruthy();
    expect(state.done).toBe(true);
    
    // Each state should have required properties
    states.forEach(s => {
      expect(s).toHaveProperty('tokens');
      expect(s).toHaveProperty('currentToken');
      expect(s).toHaveProperty('ast');
      expect(s).toHaveProperty('error');
      expect(s).toHaveProperty('done');
    });
  });
});
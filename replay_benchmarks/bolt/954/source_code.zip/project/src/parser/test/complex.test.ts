import { describe, test, expect } from 'vitest';
import { Parser } from '../parser';
import { tokenize } from '../tokenizer';
import { parse } from './utils';

describe('Complex Expressions', () => {
  test('parses print with addition and multiplication (operator precedence)', () => {
    const ast = parse('print 1 + 2 * 3');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'print',
        argument: {
          type: 'addition',
          left: { type: 'number', value: 1 },
          right: {
            type: 'multiplication',
            left: { type: 'number', value: 2 },
            right: { type: 'number', value: 3 }
          }
        }
      }]
    });
  });
});
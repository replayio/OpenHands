import { describe, test, expect } from 'vitest';
import { parse } from './utils';

describe('Array Expressions and Member Access', () => {
  test('parses empty array', () => {
    const ast = parse('var empty = []');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'varDeclaration',
        name: 'empty',
        initializer: {
          type: 'arrayExpression',
          elements: []
        }
      }]
    });
  });

  test('parses array with elements', () => {
    const ast = parse('var nums = [1, 2, 3]');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'varDeclaration',
        name: 'nums',
        initializer: {
          type: 'arrayExpression',
          elements: [
            { type: 'number', value: 1 },
            { type: 'number', value: 2 },
            { type: 'number', value: 3 }
          ]
        }
      }]
    });
  });

  test('parses array access', () => {
    const ast = parse('var nums = [1, 2, 3];\nprint nums[1]');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'varDeclaration',
          name: 'nums',
          initializer: {
            type: 'arrayExpression',
            elements: [
              { type: 'number', value: 1 },
              { type: 'number', value: 2 },
              { type: 'number', value: 3 }
            ]
          }
        },
        {
          type: 'print',
          argument: {
            type: 'memberExpression',
            object: { type: 'identifier', name: 'nums' },
            property: { type: 'number', value: 1 },
            computed: true
          }
        }
      ]
    });
  });

  test('parses nested arrays', () => {
    const ast = parse('var matrix = [[1, 2], [3, 4]]');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'varDeclaration',
        name: 'matrix',
        initializer: {
          type: 'arrayExpression',
          elements: [
            {
              type: 'arrayExpression',
              elements: [
                { type: 'number', value: 1 },
                { type: 'number', value: 2 }
              ]
            },
            {
              type: 'arrayExpression',
              elements: [
                { type: 'number', value: 3 },
                { type: 'number', value: 4 }
              ]
            }
          ]
        }
      }]
    });
  });

  test('parses complex array access', () => {
    const ast = parse('var matrix = [[1, 2], [3, 4]];\nprint matrix[1][0]');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'varDeclaration',
          name: 'matrix',
          initializer: {
            type: 'arrayExpression',
            elements: [
              {
                type: 'arrayExpression',
                elements: [
                  { type: 'number', value: 1 },
                  { type: 'number', value: 2 }
                ]
              },
              {
                type: 'arrayExpression',
                elements: [
                  { type: 'number', value: 3 },
                  { type: 'number', value: 4 }
                ]
              }
            ]
          }
        },
        {
          type: 'print',
          argument: {
            type: 'memberExpression',
            object: {
              type: 'memberExpression',
              object: { type: 'identifier', name: 'matrix' },
              property: { type: 'number', value: 1 },
              computed: true
            },
            property: { type: 'number', value: 0 },
            computed: true
          }
        }
      ]
    });
  });
});
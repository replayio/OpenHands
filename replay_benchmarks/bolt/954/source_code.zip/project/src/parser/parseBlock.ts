import { BlockNode, ParserContext, ASTNode } from './types';
import { peek, consume } from './parserUtils';
import { parseStatement } from './parseStatement';

export function parseBlock(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): BlockNode {
  onStep('Block: Start', null);
  
  const token = peek(context);
  if (!token || token.type !== 'brace' || token.value !== '{') {
    throw new Error('Expected opening brace {');
  }
  consume(context); // consume opening brace

  const statements: ASTNode[] = [];
  const partialNode: BlockNode = {
    type: 'block',
    statements: []
  };

  while (context.current < context.tokens.length) {
    const token = peek(context);
    if (!token) break;

    // End of block
    if (token.type === 'brace' && token.value === '}') {
      if (statements.length === 0) {
        throw new Error('Expected statement in block');
      }
      consume(context); // consume closing brace
      partialNode.statements = statements;
      onStep('Block: Complete', partialNode);
      return partialNode;
    }

    // Skip separators inside block
    if (token.type === 'separator') {
      consume(context);
      continue;
    }

    const statement = parseStatement(context, onStep);
    statements.push(statement);
    partialNode.statements = [...statements];
    onStep('Block: Statement Added', partialNode);
  }

  throw new Error('Expected closing brace }');
}
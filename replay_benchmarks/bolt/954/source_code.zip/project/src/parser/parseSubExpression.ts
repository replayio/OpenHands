import { ParserContext } from './types';
import { peek, createState } from './parserUtils';
import { handleBinary } from './parseBinary';

export function handleSubExpression(context: ParserContext) {
  context.currentRule = "subExpression → number ('*' number)*";
  const token = peek(context);

  if (!token || token.type === 'separator') {
    context.parsingPhase = 'expression';
    return createState(context);
  }

  if (token.type === 'number') {
    context.parsingPhase = 'number';
    return createState(context);
  }

  // Handle multiplication
  if (token.type === 'operator' && token.value === '*') {
    const binaryNode = handleBinary(context);
    if (binaryNode) {
      context.parsingPhase = 'number';
      return createState(context);
    }
  }

  context.parsingPhase = 'expression';
  return createState(context);
}
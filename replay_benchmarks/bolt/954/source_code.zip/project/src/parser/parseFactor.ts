import { ASTNode, ParserContext } from './types';
import { peek, consume } from './parserUtils';
import { parseNumber } from './parseNumber';
import { parseIdentifier } from './parseIdentifier';
import { parseGroup } from './parseGroup';
import { parseArrayExpression } from './parseArrayExpression';
import { parseMemberExpression } from './parseMemberExpression';

export function parseFactor(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): ASTNode {
  onStep('Factor', null);

  const token = peek(context);
  if (!token) {
    throw new Error('Unexpected end of input');
  }

  let node: ASTNode;

  if (token.type === 'number') {
    node = parseNumber(context, onStep);
  } else if (token.type === 'identifier') {
    node = parseIdentifier(context, onStep);
  } else if (token.type === 'paren' && token.value === '(') {
    node = parseGroup(context, onStep);
  } else if (token.type === 'bracket' && token.value === '[') {
    node = parseArrayExpression(context, onStep);
  } else {
    throw new Error(`Expected number, identifier, '(', or '[', got ${token.type}`);
  }

  // Check for array access or property access after the initial factor
  while (peek(context)?.type === 'bracket' && peek(context)?.value === '[') {
    node = parseMemberExpression(context, node, onStep);
  }

  return node;
}
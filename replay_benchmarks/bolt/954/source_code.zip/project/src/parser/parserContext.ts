import { Token } from '../types/token';
import { ASTNode } from '../types/ast';

export type ParsingPhase = 'start' | 'statement' | 'expression' | 'term' | 'number' | 'complete';

export interface ParserContext {
  tokens: Token[];
  current: number;
  ast: ASTNode | null;
  currentRule?: string;
  parsingPhase: ParsingPhase;
  error?: string;
}

export interface ParserState {
  tokens: Token[];
  currentToken: number;
  ast: ASTNode | null;
  error: string | null;
  done: boolean;
  rule?: string;
}
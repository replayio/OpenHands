import { PrintNode, ParserContext, ASTNode } from './types';
import { peek, consume } from './parserUtils';
import { parseExpression } from './parseExpression';

export function parsePrint(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): PrintNode {
  const token = peek(context);
  
  if (!token || token.type !== 'print') {
    throw new Error(`Expected 'print', got ${token?.type || 'end of input'}`);
  }

  consume(context); // consume 'print'
  
  // Ensure there's an expression after 'print'
  const nextToken = peek(context);
  if (!nextToken) {
    throw new Error('Expected expression after print statement');
  }

  // Allow parentheses, numbers, identifiers, or operators
  if (!['paren', 'number', 'identifier'].includes(nextToken.type)) {
    throw new Error(`Expected expression after print statement, got ${nextToken.type}`);
  }
  
  const argument = parseExpression(context, onStep);
  
  const node: PrintNode = {
    type: 'print',
    argument
  };

  onStep('Print', node);
  return node;
}
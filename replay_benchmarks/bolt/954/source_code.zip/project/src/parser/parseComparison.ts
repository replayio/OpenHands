import { ComparisonNode, ParserContext, ASTNode } from './types';
import { peek, consume } from './parserUtils';
import { parseExpression } from './parseExpression';

export function parseComparison(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): ComparisonNode {
  const left = parseExpression(context, onStep);

  const token = peek(context);
  if (!token || token.type !== 'comparison') {
    throw new Error('Expected comparison operator');
  }

  const operator = token.value as '<' | '>' | '<=' | '>=' | '==' | '!=';
  consume(context); // consume operator

  const right = parseExpression(context, onStep);

  const node: ComparisonNode = {
    type: 'comparison',
    operator,
    left,
    right
  };

  onStep('Comparison', node);
  return node;
}
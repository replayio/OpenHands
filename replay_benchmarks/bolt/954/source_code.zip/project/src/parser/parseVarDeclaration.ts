import { VarDeclarationNode, ParserContext, ASTNode } from './types';
import { peek, consume, addVariableToScope } from './parserUtils';
import { parseExpression } from './parseExpression';

export function parseVarDeclaration(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): VarDeclarationNode {
  // Consume 'var' keyword
  consume(context);

  // Get identifier
  const identifier = peek(context);
  if (!identifier || identifier.type !== 'identifier') {
    throw new Error('Expected identifier after var keyword');
  }
  const variableName = identifier.value;
  consume(context);

  // Add to current scope
  addVariableToScope(context.currentScope, variableName);

  // Get equals sign
  const equals = peek(context);
  if (!equals || equals.type !== 'equals') {
    throw new Error('Expected = after variable name');
  }
  consume(context);

  // Get initializer expression
  const initializer = parseExpression(context, onStep);

  const node: VarDeclarationNode = {
    type: 'varDeclaration',
    name: variableName,
    initializer
  };

  onStep('VarDeclaration', node);
  return node;
}
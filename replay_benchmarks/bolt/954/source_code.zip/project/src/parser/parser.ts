import { Token, ASTNode, ParserState, ParserContext } from './types';
import { parseProgram } from './parseProgram';

export class Parser {
  private tokens: Token[];
  private context: ParserContext;
  private steps: { nodeName: string; node: ASTNode | null }[];
  private currentStep: number;
  private lastAst: string | null;

  constructor(tokens: Token[]) {
    this.tokens = tokens.filter(t => t.type !== 'whitespace');
    this.context = {
      tokens: this.tokens,
      current: 0,
      ast: null,
      parsingPhase: 'start',
      variables: new Set(),
      functions: new Set()
    };
    this.steps = [];
    this.currentStep = -1;
    this.lastAst = null;
  }

  private addStep(nodeName: string, node: ASTNode | null) {
    // Always add steps with nodeName, regardless of AST changes
    if (nodeName) {
      this.steps.push({ 
        nodeName, 
        node: node ? structuredClone(node) : null 
      });
      if (node) {
        this.lastAst = JSON.stringify(node);
      }
      return;
    }

    // For steps without nodeName, only add if AST has changed
    const currentAst = node ? JSON.stringify(node) : null;
    if (currentAst !== this.lastAst) {
      this.steps.push({ 
        nodeName: '', 
        node: node ? structuredClone(node) : null 
      });
      if (node) {
        this.lastAst = currentAst;
      }
    }
  }

  private parse(): void {
    try {
      const ast = parseProgram(this.tokens, 0, (nodeName, node) => {
        this.addStep(nodeName, node);
      });
      this.context.ast = ast;
      this.addStep('Parsing complete', ast);
    } catch (error) {
      this.addStep(`Error: ${(error as Error).message}`, null);
    }
  }

  public step(): ParserState {
    if (this.currentStep === -1) {
      this.parse();
    }
    
    this.currentStep++;

    if (this.currentStep >= this.steps.length) {
      return {
        tokens: this.tokens,
        currentToken: this.context.current,
        ast: this.context.ast,
        error: null,
        done: true,
        nodeName: 'Parsing complete'
      };
    }

    const step = this.steps[this.currentStep];
    const isError = step.nodeName.startsWith('Error:');

    return {
      tokens: this.tokens,
      currentToken: this.context.current,
      ast: step.node,
      error: isError ? step.nodeName.slice(7) : null,
      done: isError || this.currentStep === this.steps.length - 1,
      nodeName: isError ? undefined : step.nodeName
    };
  }
}
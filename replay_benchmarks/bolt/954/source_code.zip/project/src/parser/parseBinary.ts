import { ASTNode, ParserContext } from './types';
import { peek, consume } from './parserUtils';
import { parseNumber } from './parseNumber';

export function handleBinary(context: ParserContext): ASTNode {
  const token = peek(context);
  if (!token) {
    throw new Error('Unexpected end of input');
  }

  if (token.type === 'operator') {
    const operator = token.value;
    consume(context); // consume operator

    const right = parseNumber(context);
    const left = context.partialNode;
    context.partialNode = null;

    if (!left) {
      throw new Error('Invalid binary operation');
    }

    return {
      type: operator === '+' ? 'addition' : 'multiplication',
      left,
      right
    };
  }

  throw new Error(`Expected operator, got ${token.type}`);
}
import { GroupNode, ParserContext, ASTNode } from './types';
import { peek, consume } from './parserUtils';
import { parseExpression } from './parseExpression';

export function parseGroup(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): GroupNode {
  const token = peek(context);
  if (!token || token.type !== 'paren' || token.value !== '(') {
    throw new Error("Expected '('");
  }
  consume(context); // consume opening paren

  const expression = parseExpression(context, onStep);

  const closeParen = peek(context);
  if (!closeParen || closeParen.type !== 'paren' || closeParen.value !== ')') {
    throw new Error("Expected ')'");
  }
  consume(context); // consume closing paren

  const node: GroupNode = {
    type: 'group',
    expression
  };

  onStep('Group', node);
  return node;
}
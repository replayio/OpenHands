import { ASTNode, ParserContext } from './types';
import { peek, consume } from './parserUtils';
import { parseExpression } from './parseExpression';
import { parsePrint } from './parsePrint';
import { parseVarDeclaration } from './parseVarDeclaration';
import { parseAssignment } from './parseAssignment';
import { parseIf } from './parseIf';
import { parseFunctionDeclaration } from './parseFunctionDeclaration';
import { parseFunctionCall } from './parseFunctionCall';
import { parseReturn } from './parseReturn';

export function parseStatement(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): ASTNode {
  // Skip any extra separators
  while (peek(context)?.type === 'separator') {
    consume(context);
  }

  const token = peek(context);

  if (!token) {
    throw new Error('Unexpected end of input');
  }

  if (token.type === 'print') {
    onStep('Statement: Print', null);
    return parsePrint(context, onStep);
  } else if (token.type === 'var') {
    onStep('Statement: Variable Declaration', null);
    return parseVarDeclaration(context, onStep);
  } else if (token.type === 'if') {
    onStep('Statement: If', null);
    return parseIf(context, onStep);
  } else if (token.type === 'function') {
    onStep('Statement: Function Declaration', null);
    return parseFunctionDeclaration(context, onStep);
  } else if (token.type === 'return') {
    onStep('Statement: Return', null);
    return parseReturn(context, onStep);
  } else if (token.type === 'identifier') {
    // Look ahead to determine if this is an assignment or function call
    const nextToken = context.tokens[context.current + 1];
    if (nextToken?.type === 'equals') {
      onStep('Statement: Assignment', null);
      return parseAssignment(context, onStep);
    } else if (nextToken?.type === 'paren' && nextToken.value === '(') {
      onStep('Statement: Function Call', null);
      return parseFunctionCall(context, onStep);
    }
  }

  onStep('Statement: Expression', null);
  return parseExpression(context, onStep);
}
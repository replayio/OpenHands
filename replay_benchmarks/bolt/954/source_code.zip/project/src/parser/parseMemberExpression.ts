import { MemberExpressionNode, ParserContext, ASTNode } from './types';
import { peek, consume } from './parserUtils';
import { parseExpression } from './parseExpression';

export function parseMemberExpression(context: ParserContext, object: ASTNode, onStep: (nodeName: string, node: ASTNode | null) => void): MemberExpressionNode {
  onStep('Member Expression: Start', null);

  // Check for property access (e.g., array.length)
  const nextToken = peek(context);
  if (nextToken?.type === 'dot') {
    consume(context); // consume dot
    const property = peek(context);
    if (!property || property.type !== 'identifier') {
      throw new Error('Expected property name after dot');
    }
    consume(context); // consume property name

    const node: MemberExpressionNode = {
      type: 'memberExpression',
      object,
      property: { type: 'identifier', name: property.value },
      computed: false
    };

    onStep('Member Expression: Property Access', node);
    return node;
  }

  // Handle array index access
  if (nextToken?.type === 'bracket' && nextToken.value === '[') {
    consume(context); // consume opening bracket

    const property = parseExpression(context, onStep);

    const closeBracket = peek(context);
    if (!closeBracket || closeBracket.type !== 'bracket' || closeBracket.value !== ']') {
      throw new Error('Expected ]');
    }
    consume(context);

    const node: MemberExpressionNode = {
      type: 'memberExpression',
      object,
      property,
      computed: true
    };

    onStep('Member Expression: Index Access', node);
    return node;
  }

  throw new Error('Expected [ or . after array expression');
}
export function tokenize(input: string): Token[] {
  const tokens: Token[] = [];
  let position = 0;

  while (position < input.length) {
    let char = input[position];

    // Skip whitespace but keep newlines for visualization
    if (char === ' ' || char === '\t') {
      tokens.push({ type: 'whitespace', value: char, position });
      position++;
      continue;
    }

    // Handle newlines and semicolons as statement separators
    if (char === '\n' || char === ';') {
      tokens.push({ type: 'separator', value: char === '\n' ? '\\n' : ';', position });
      position++;
      continue;
    }

    // Handle parentheses
    if (char === '(' || char === ')') {
      tokens.push({ type: 'paren', value: char, position });
      position++;
      continue;
    }

    // Handle square brackets
    if (char === '[' || char === ']') {
      tokens.push({ type: 'bracket', value: char, position });
      position++;
      continue;
    }

    // Handle curly braces
    if (char === '{' || char === '}') {
      tokens.push({ type: 'brace', value: char, position });
      position++;
      continue;
    }

    // Handle dot operator
    if (char === '.') {
      tokens.push({ type: 'dot', value: char, position });
      position++;
      continue;
    }

    // Handle comma
    if (char === ',') {
      tokens.push({ type: 'comma', value: char, position });
      position++;
      continue;
    }

    // Numbers
    if (/[0-9]/.test(char)) {
      let value = '';
      let start = position;
      while (position < input.length && /[0-9]/.test(input[position])) {
        value += input[position];
        position++;
      }
      tokens.push({ type: 'number', value, position: start });
      continue;
    }

    // Comparison operators and equals
    if (['<', '>', '=', '!'].includes(char)) {
      let value = char;
      let start = position;
      position++;
      
      if (position < input.length && input[position] === '=') {
        value += '=';
        position++;
      }
      
      if (value === '=') {
        tokens.push({ type: 'equals', value, position: start });
      } else {
        tokens.push({ type: 'comparison', value, position: start });
      }
      continue;
    }

    // Operators
    if (['+', '*', '-'].includes(char)) {
      tokens.push({ type: 'operator', value: char, position });
      position++;
      continue;
    }

    // Keywords and identifiers
    if (/[a-zA-Z_]/.test(char)) {
      let value = '';
      let start = position;
      while (position < input.length && /[a-zA-Z0-9_]/.test(input[position])) {
        value += input[position];
        position++;
      }

      if (value === 'print') {
        tokens.push({ type: 'print', value, position: start });
      } else if (value === 'var') {
        tokens.push({ type: 'var', value, position: start });
      } else if (value === 'if') {
        tokens.push({ type: 'if', value, position: start });
      } else if (value === 'function') {
        tokens.push({ type: 'function', value, position: start });
      } else if (value === 'return') {
        tokens.push({ type: 'return', value, position: start });
      } else {
        tokens.push({ type: 'identifier', value, position: start });
      }
      continue;
    }

    throw new Error(`Unexpected character '${char}' at position ${position}`);
  }

  return tokens;
}
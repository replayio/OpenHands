import React, { useState, useEffect } from 'react';
import { Parser } from './parser/parser';
import { tokenize } from './parser/tokenizer';
import { ParserState } from './parser/types';
import { CodeInput } from './components/CodeInput';
import { ParserOutput } from './components/ParserOutput';

export default function App() {
  const [code, setCode] = useState('print 1 + 2 * 3');
  const [isRunning, setIsRunning] = useState(false);
  const [parserStates, setParserStates] = useState<ParserState[]>([]);
  const [parser, setParser] = useState<Parser | null>(null);
  const [shouldParse, setShouldParse] = useState(false);
  const timeoutRef = React.useRef<number | null>(null);

  const reset = () => {
    if (timeoutRef.current) {
      window.clearTimeout(timeoutRef.current);
    }
    setIsRunning(false);
    setParser(null);
    setShouldParse(false);
  };

  const startParsing = () => {
    try {
      setParserStates([]);
      const tokens = tokenize(code);
      const newParser = new Parser(tokens);
      setParser(newParser);
      setIsRunning(true);
    } catch (error) {
      setParserStates([{
        tokens: [],
        currentToken: 0,
        ast: null,
        error: (error as Error).message,
        done: true
      }]);
    }
  };

  const handleCodeChange = (newCode: string, parse: boolean = false) => {
    setCode(newCode);
    if (parse) {
      reset();
      setShouldParse(true);
    }
  };

  useEffect(() => {
    if (shouldParse) {
      startParsing();
      setShouldParse(false);
    }
  }, [code, shouldParse]);

  useEffect(() => {
    if (isRunning && parser) {
      const step = () => {
        const state = parser.step();
        setParserStates(prev => [...prev, state]);

        if (!state.done && isRunning) {
          timeoutRef.current = window.setTimeout(step, 50);
        } else {
          setIsRunning(false);
        }
      };

      step();
    }

    return () => {
      if (timeoutRef.current) {
        window.clearTimeout(timeoutRef.current);
      }
    };
  }, [isRunning, parser]);

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">
      <div className="p-4 bg-white shadow-sm">
        <div className="max-w-[1400px] mx-auto">
          <h1 className="text-3xl font-bold text-gray-800">Parser Visualizer</h1>
        </div>
      </div>
      
      <div className="flex-1 p-4">
        <div className="max-w-[1400px] mx-auto h-full flex gap-6">
          <div className="w-1/2">
            <CodeInput
              code={code}
              onCodeChange={handleCodeChange}
              onParse={startParsing}
              isRunning={isRunning}
              onReset={reset}
            />
          </div>
          <div className="w-1/2 flex-1">
            <ParserOutput 
              parserStates={parserStates}
              code={code}
              isRunning={isRunning}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
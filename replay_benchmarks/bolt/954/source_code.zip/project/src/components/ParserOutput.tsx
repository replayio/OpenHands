import React, { useState } from 'react';
import { ParserState } from '../parser/types';
import { CheckCircle, XCircle, Clock, ChevronDown, ChevronUp } from 'lucide-react';
import { ParserSteps } from './ParserSteps';
import { ASTVisualizer } from './ASTVisualizer';

interface ParserOutputProps {
  parserStates: ParserState[];
  code: string;
  isRunning?: boolean;
}

export function ParserOutput({ parserStates, code, isRunning }: ParserOutputProps) {
  const [showDetails, setShowDetails] = useState(false);
  const lastState = parserStates[parserStates.length - 1];
  const hasError = lastState?.error;

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-lg font-semibold mb-4">Result</h2>
        
        {isRunning ? (
          <div className="flex items-center gap-3">
            <Clock className="w-6 h-6 text-blue-500 animate-spin" />
            <span className="text-blue-600 font-medium">Parsing...</span>
          </div>
        ) : parserStates.length === 0 ? (
          <div className="text-gray-500">
            No parsing results yet
          </div>
        ) : hasError ? (
          <div className="flex items-center gap-3">
            <XCircle className="w-6 h-6 text-red-500" />
            <span className="text-red-600 font-medium">Parser error.</span>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-green-500" />
              <span className="text-green-600 font-medium">Parsing succeeded!</span>
            </div>
            {lastState.ast && (
              <div className="mt-4 border-t pt-4">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Final AST</h3>
                <ASTVisualizer ast={lastState.ast} />
              </div>
            )}
          </div>
        )}

        <button
          onClick={() => setShowDetails(!showDetails)}
          className="mt-4 flex items-center gap-2 px-3 py-1.5 text-sm bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
        >
          {showDetails ? (
            <>
              <ChevronUp className="w-4 h-4" />
              Hide Details
            </>
          ) : (
            <>
              <ChevronDown className="w-4 h-4" />
              Show Details
            </>
          )}
        </button>
      </div>

      {showDetails && (
        <ParserSteps parserStates={parserStates} code={code} />
      )}
    </div>
  );
}
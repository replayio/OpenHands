import React, { useEffect, useRef } from 'react';
import { graphviz } from 'd3-graphviz';
import { ASTNode } from '../parser/types';
import { Graphviz } from '@hpcc-js/wasm';

// Initialize WASM
let graphvizInitialized = false;
async function initGraphviz() {
  if (!graphvizInitialized) {
    await Graphviz.load();
    graphvizInitialized = true;
  }
}

function calculateGraphDimensions(ast: ASTNode | null): { width: number; height: number } {
  if (!ast) return { width: 0, height: 0 };

  const nodeDimensions = {
    base: { width: 100, height: 40 },
    spacing: { horizontal: 50, vertical: 30 }
  };

  function traverse(node: any): { width: number; height: number; nodes: number } {
    let width = nodeDimensions.base.width;
    let height = nodeDimensions.base.height;
    let totalNodes = 1;

    // Get all child nodes
    const children = Object.entries(node)
      .filter(([key]) => key !== 'type')
      .flatMap(([_, value]) => {
        if (Array.isArray(value)) {
          return value.filter(item => item && typeof item === 'object');
        }
        return value && typeof value === 'object' ? [value] : [];
      });

    if (children.length > 0) {
      const childrenMetrics = children.map(child => traverse(child));
      const childrenWidth = childrenMetrics.reduce((sum, m) => sum + m.width + nodeDimensions.spacing.horizontal, 0);
      const maxChildHeight = Math.max(...childrenMetrics.map(m => m.height));
      totalNodes += childrenMetrics.reduce((sum, m) => sum + m.nodes, 0);
      width = Math.max(width, childrenWidth);
      height += maxChildHeight + nodeDimensions.spacing.vertical;
    }

    return { width, height, nodes: totalNodes };
  }

  const dimensions = traverse(ast);
  return {
    width: dimensions.width,
    height: Math.max(200, dimensions.height * 1.2)
  };
}

function generateNodeLabel(node: any): string {
  let label = node.type;

  // Add relevant values based on node type
  const valueProps = ['name', 'value', 'operator', 'callee'];
  for (const prop of valueProps) {
    if (prop in node && typeof node[prop] !== 'object') {
      label += `\\n${node[prop]}`;
      break;
    }
  }

  return label;
}

function generateDot(node: any, parentId: string | null = null): string {
  const currentId = `node_${Math.random().toString(36).substr(2, 9)}`;
  const label = generateNodeLabel(node);
  
  let dot = `  "${currentId}" [label="${label}"];\n`;
  
  if (parentId !== null) {
    dot += `  "${parentId}" -> "${currentId}";\n`;
  }

  // Get all child nodes
  const children = Object.entries(node)
    .filter(([key]) => key !== 'type')
    .flatMap(([_, value]) => {
      if (Array.isArray(value)) {
        return value.filter(item => item && typeof item === 'object');
      }
      return value && typeof value === 'object' ? [value] : [];
    });

  children.forEach(child => {
    dot += generateDot(child, currentId);
  });

  return dot;
}

function generateDotFromAST(ast: ASTNode | null): string {
  if (!ast) return '';

  return generateDot(ast, null);
}

interface ASTVisualizerProps {
  ast: ASTNode | null;
}

export function ASTVisualizer({ ast }: ASTVisualizerProps) {
  const graphRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!graphRef.current || !ast) return;

    const renderGraph = async () => {
      await initGraphviz();

      const dimensions = calculateGraphDimensions(ast);
      
      const dotGraph = `digraph {
        node [shape=box, style="rounded,filled", fillcolor=white, fontname="Arial"];
        edge [fontname="Arial"];
        rankdir=LR;
        ranksep=0.5;
        nodesep=0.8;
        
        ${generateDotFromAST(ast)}
      }`;

      graphviz(graphRef.current, {
        fit: true,
        height: dimensions.height,
        width: '100%',
        zoom: false
      })
        .renderDot(dotGraph)
        .on('end', function() {
          const nodes = document.querySelectorAll('.node');
          nodes.forEach(node => {
            node.addEventListener('mouseenter', () => {
              (node as HTMLElement).style.opacity = '0.8';
            });
            node.addEventListener('mouseleave', () => {
              (node as HTMLElement).style.opacity = '1';
            });
          });
        });
    };

    renderGraph().catch(console.error);
  }, [ast]);

  if (!ast) {
    return <div className="text-gray-500 italic">No AST to display</div>;
  }

  return (
    <div className="bg-white rounded-lg p-4 shadow-sm">
      <div ref={graphRef} className="w-full" />
    </div>
  );
}
// DON'T REMOVE. ONLY DISABLED TEMPORARILY.
import React from 'react';
import { ParserState } from '../parser/types';
import { ASTVisualizer } from './ASTVisualizer';
import { ClipboardCopy } from 'lucide-react';

interface ParserStepsProps {
  parserStates: ParserState[];
  code: string;
}

interface DebugStep {
  nodeName: string;
  ast: any;
  error: string | null;
  done: boolean;
  currentToken: number;
}

interface DebugData {
  codeInput: string;
  steps: DebugStep[];
}

function calculateStepHeight(state: ParserState): number {
  if (!state.ast) return 0;
  
  let complexity = 0;
  
  function countNodes(node: any): number {
    if (!node) return 0;
    
    let count = 1;
    
    if (node.type === 'program') {
      count += node.statements.reduce((sum: number, stmt: any) => sum + countNodes(stmt), 0);
    } else {
      if (node.left) count += countNodes(node.left);
      if (node.right) count += countNodes(node.right);
      if (node.argument) count += countNodes(node.argument);
      if (node.initializer) count += countNodes(node.initializer);
      if (node.condition) count += countNodes(node.condition);
      if (node.consequent) count += countNodes(node.consequent);
      if (node.statements) count += node.statements.reduce((sum: number, stmt: any) => sum + countNodes(stmt), 0);
      if (node.expression) count += countNodes(node.expression);
    }
    
    return count;
  }
  
  complexity = countNodes(state.ast);
  return complexity * 30; // 30px per node
}

export function ParserSteps({ parserStates, code }: ParserStepsProps) {
  const copyDebugData = () => {
    const debugData: DebugData = {
      codeInput: code,
      steps: parserStates.map(state => ({
        nodeName: state.nodeName || '',
        ast: state.ast,
        error: state.error,
        done: state.done,
        currentToken: state.currentToken
      }))
    };

    // Filter out steps with no meaningful changes
    const filteredSteps = debugData.steps.filter((step, index, array) => {
      // Always keep first and last steps
      if (index === 0 || index === array.length - 1) return true;
      
      // Always keep steps with errors
      if (step.error) return true;
      
      // Always keep steps with node names
      if (step.nodeName) return true;
      
      // Keep steps where AST changed from previous step
      const prevStep = array[index - 1];
      return JSON.stringify(step.ast) !== JSON.stringify(prevStep.ast);
    });

    const cleanedDebugData = {
      ...debugData,
      steps: filteredSteps
    };

    navigator.clipboard.writeText(JSON.stringify(cleanedDebugData, null, 2));
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 flex flex-col h-[calc(100vh-8rem)]">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Parser Steps</h2>
        <button
          onClick={copyDebugData}
          className="flex items-center gap-2 px-3 py-1.5 text-sm bg-gray-100 hover:bg-gray-200 rounded-md transition-colors"
          title="Copy debug data"
        >
          <ClipboardCopy className="w-4 h-4" />
          Copy Debug Data
        </button>
      </div>
      <div className="flex-1 overflow-y-auto">
        <div className="space-y-0">
          {parserStates.map((state, index) => {
            const prevAst = index > 0 ? JSON.stringify(parserStates[index - 1].ast) : null;
            const currentAst = JSON.stringify(state.ast);
            const astChanged = prevAst !== currentAst;
            
            return (
              <div 
                key={index} 
                className="border-l-2 border-blue-500 pl-4 py-2"
              >
                <div className="font-mono text-sm">
                  {state.error ? (
                    <div className="text-red-600">
                      <div className="font-bold">Error at step {index + 1}:</div>
                      <div className="mt-1">{state.error}</div>
                    </div>
                  ) : (
                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="text-blue-600 font-bold">Step {index + 1}</span>
                        {state.nodeName && (
                          <span className="text-purple-600">
                            {state.nodeName}
                          </span>
                        )}
                        {state.currentToken > 0 && (
                          <span className="text-gray-500">
                            (token: {state.currentToken})
                          </span>
                        )}
                      </div>
                      {astChanged && state.ast && (
                        <div className="mt-2">
                          <ASTVisualizer ast={state.ast} />
                        </div>
                      )}
                      {state.done && (
                        <div className="text-green-600 mt-2">
                          Parsing complete!
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
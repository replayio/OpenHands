import { Engine, Render, World, Bodies, Composite, Mouse, MouseConstraint, Body } from 'matter-js';
import { WORLD_SIZE, DISPLAY_SIZE, COLORS, SHAPE_CONFIG } from './constants';
import type { PhysicsWorld } from '../types/physics';

export function createWalls() {
  return [
    Bodies.rectangle(WORLD_SIZE / 2, 0, WORLD_SIZE, 2, { isStatic: true }), // top
    Bodies.rectangle(WORLD_SIZE / 2, WORLD_SIZE, WORLD_SIZE, 2, { isStatic: true }), // bottom
    Bodies.rectangle(0, WORLD_SIZE / 2, 2, WORLD_SIZE, { isStatic: true }), // left
    Bodies.rectangle(WORLD_SIZE, WORLD_SIZE / 2, 2, WORLD_SIZE, { isStatic: true }) // right
  ];
}

export function createRandomShapes() {
  const shapes = [];
  
  for (let i = 0; i < SHAPE_CONFIG.COUNT; i++) {
    const x = Math.random() * (WORLD_SIZE * 0.8) + (WORLD_SIZE * 0.1);
    const y = Math.random() * (WORLD_SIZE * 0.8) + (WORLD_SIZE * 0.1);
    const size = Math.random() * (SHAPE_CONFIG.MAX_SIZE - SHAPE_CONFIG.MIN_SIZE) + SHAPE_CONFIG.MIN_SIZE;
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    
    let shape;
    const shapeType = Math.floor(Math.random() * 3);
    
    switch (shapeType) {
      case 0:
        shape = Bodies.circle(x, y, size / 2, {
          render: { fillStyle: color },
          frictionAir: 0
        });
        break;
      case 1:
        shape = Bodies.rectangle(x, y, size, size, {
          render: { fillStyle: color },
          frictionAir: 0
        });
        break;
      case 2:
        shape = Bodies.polygon(x, y, 3, size / 2, {
          render: { fillStyle: color },
          frictionAir: 0
        });
        break;
    }
    
    const speed = Math.random() * (SHAPE_CONFIG.MAX_SPEED - SHAPE_CONFIG.MIN_SPEED) + SHAPE_CONFIG.MIN_SPEED;
    const angle = Math.random() * Math.PI * 2;
    Body.setVelocity(shape, {
      x: speed * Math.cos(angle),
      y: speed * Math.sin(angle)
    });
    
    shapes.push(shape);
  }
  
  return shapes;
}

export function setupPhysicsWorld(container: HTMLElement): PhysicsWorld {
  const engine = Engine.create({
    gravity: { x: 0, y: 0, scale: 0 }
  });

  const render = Render.create({
    element: container,
    engine: engine,
    options: {
      width: DISPLAY_SIZE,
      height: DISPLAY_SIZE,
      wireframes: false,
      background: '#f3f4f6',
      pixelRatio: window.devicePixelRatio,
      hasBounds: true
    }
  });

  // Scale the render view to match the physics world size
  const scaleFactor = DISPLAY_SIZE / WORLD_SIZE;
  render.bounds.min.x = 0;
  render.bounds.min.y = 0;
  render.bounds.max.x = WORLD_SIZE;
  render.bounds.max.y = WORLD_SIZE;
  render.options.width = DISPLAY_SIZE;
  render.options.height = DISPLAY_SIZE;
  render.options.scale = scaleFactor;

  const walls = createWalls();
  const shapes = createRandomShapes();

  Composite.add(engine.world, [...walls, ...shapes]);

  const mouse = Mouse.create(render.canvas);
  mouse.pixelRatio = window.devicePixelRatio;
  
  const mouseConstraint = MouseConstraint.create(engine, {
    mouse: mouse,
    constraint: {
      stiffness: 0.2,
      render: { visible: false }
    }
  });

  Composite.add(engine.world, mouseConstraint);
  render.mouse = mouse;

  return {
    engine,
    render,
    shapes,
    cleanup: () => {
      Render.stop(render);
      World.clear(engine.world, false);
      Engine.clear(engine);
      render.canvas.remove();
      render.canvas = null;
      render.context = null;
      render.textures = {};
    }
  };
}
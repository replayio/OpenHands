export const WORLD_SIZE = 100;
export const DISPLAY_SIZE = 600;
export const SCALE_FACTOR = WORLD_SIZE / DISPLAY_SIZE;

export const COLORS = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6'];

export const SHAPE_CONFIG = {
  MIN_SIZE: 4.5,
  MAX_SIZE: 12,
  MIN_SPEED: 2, // Increased minimum speed
  MAX_SPEED: 5, // Adjusted maximum speed for better control
  COUNT: 10
};
import { World, Composite } from 'matter-js';
import type { PhysicsWorld } from '../types/physics';
import { createEngine } from './engine';
import { setupRenderer } from './renderer';
import { createWalls } from './walls';
import { createRandomShapes } from './shapes';

export function setupPhysicsWorld(container: HTMLElement): PhysicsWorld {
  // Create engine with no gravity and sleeping disabled
  const engine = createEngine();
  
  // Setup renderer and mouse constraint
  const { render, mouseConstraint } = setupRenderer(container, engine);
  
  // Create walls and shapes
  const walls = createWalls();
  const shapes = createRandomShapes();

  // Add all bodies to the world
  World.add(engine.world, [...walls, ...shapes]);

  return {
    engine,
    render,
    shapes,
    mouseConstraint,
    cleanup: () => {
      World.clear(engine.world, false);
      Engine.clear(engine);
      render.canvas.remove();
      render.canvas = null;
      render.context = null;
      render.textures = {};
    }
  };
}
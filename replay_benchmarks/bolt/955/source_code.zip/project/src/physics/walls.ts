import { Bodies } from 'matter-js';
import { WORLD_SIZE } from '../utils/constants';

export function createWalls() {
  return [
    Bodies.rectangle(WORLD_SIZE / 2, 0, WORLD_SIZE, 2, { isStatic: true }), // top
    Bodies.rectangle(WORLD_SIZE / 2, WORLD_SIZE, WORLD_SIZE, 2, { isStatic: true }), // bottom
    Bodies.rectangle(0, WORLD_SIZE / 2, 2, WORLD_SIZE, { isStatic: true }), // left
    Bodies.rectangle(WORLD_SIZE, WORLD_SIZE / 2, 2, WORLD_SIZE, { isStatic: true }) // right
  ];
}
import { Bodies, Body } from 'matter-js';
import { WORLD_SIZE, COLORS, SHAPE_CONFIG } from '../utils/constants';

export function createRandomShapes() {
  const shapes = [];
  
  for (let i = 0; i < SHAPE_CONFIG.COUNT; i++) {
    const x = Math.random() * (WORLD_SIZE * 0.8) + (WORLD_SIZE * 0.1);
    const y = Math.random() * (WORLD_SIZE * 0.8) + (WORLD_SIZE * 0.1);
    const size = Math.random() * (SHAPE_CONFIG.MAX_SIZE - SHAPE_CONFIG.MIN_SIZE) + SHAPE_CONFIG.MIN_SIZE;
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    
    let shape;
    const shapeType = Math.floor(Math.random() * 3);
    
    const commonOptions = {
      render: { fillStyle: color },
      frictionAir: 0.001, // Add a tiny bit of friction
      restitution: 0.8, // Make shapes bouncy
      density: 0.001 // Lower density for better movement
    };
    
    switch (shapeType) {
      case 0:
        shape = Bodies.circle(x, y, size / 2, commonOptions);
        break;
      case 1:
        shape = Bodies.rectangle(x, y, size, size, commonOptions);
        break;
      case 2:
        shape = Bodies.polygon(x, y, 3, size / 2, commonOptions);
        break;
    }
    
    // Set initial velocity
    const speed = Math.random() * (SHAPE_CONFIG.MAX_SPEED - SHAPE_CONFIG.MIN_SPEED) + SHAPE_CONFIG.MIN_SPEED;
    const angle = Math.random() * Math.PI * 2;
    Body.setVelocity(shape, {
      x: speed * Math.cos(angle),
      y: speed * Math.sin(angle)
    });
    
    shapes.push(shape);
  }
  
  return shapes;
}
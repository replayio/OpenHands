import { Engine, Render, Mouse, MouseConstraint, Composite } from 'matter-js';
import { WORLD_SIZE, DISPLAY_SIZE } from '../utils/constants';

export function setupRenderer(container: HTMLElement, engine: Matter.Engine) {
  const render = Render.create({
    element: container,
    engine: engine,
    options: {
      width: DISPLAY_SIZE,
      height: DISPLAY_SIZE,
      wireframes: false,
      background: '#f3f4f6',
      pixelRatio: window.devicePixelRatio,
      hasBounds: true
    }
  });

  // Scale the render view to match the physics world size
  const scaleFactor = DISPLAY_SIZE / WORLD_SIZE;
  render.bounds.min.x = 0;
  render.bounds.min.y = 0;
  render.bounds.max.x = WORLD_SIZE;
  render.bounds.max.y = WORLD_SIZE;
  render.options.width = DISPLAY_SIZE;
  render.options.height = DISPLAY_SIZE;
  render.options.scale = scaleFactor;

  const mouse = Mouse.create(render.canvas);
  mouse.pixelRatio = window.devicePixelRatio;
  
  const mouseConstraint = MouseConstraint.create(engine, {
    mouse: mouse,
    constraint: {
      stiffness: 0.2,
      render: { visible: false }
    }
  });

  Composite.add(engine.world, mouseConstraint);
  render.mouse = mouse;

  return { render, mouseConstraint };
}
import { Engine } from 'matter-js';

export function createEngine() {
  return Engine.create({
    gravity: { x: 0, y: 0 },
    enableSleeping: false
  });
}
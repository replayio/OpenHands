import { Runner, Events } from 'matter-js';
import type { PhysicsWorld } from '../../types/physics';

export function useCleanup(
  world: PhysicsWorld | null,
  runner: Matter.Runner,
  updateStats: () => void,
  resetStats: (canvas: HTMLCanvasElement) => void
) {
  return () => {
    if (!world) return;

    const { engine, render } = world;

    // Remove event listeners
    Events.off(engine, 'afterUpdate', updateStats);
    render.canvas.removeEventListener('mousemove', updateStats);
    render.canvas.removeEventListener('mouseleave', () => resetStats(render.canvas));

    // Stop the physics simulation
    Runner.stop(runner);

    // Clean up the world
    world.cleanup();
  };
}
import { useState } from 'react';
import { Vector, Query } from 'matter-js';
import type { PhysicsStats } from '../../types/physics';
import { WORLD_SIZE, DISPLAY_SIZE } from '../../utils/constants';

export function useStats() {
  const [hoveredBody, setHoveredBody] = useState<PhysicsStats | null>(null);

  const updateStats = (render: Matter.Render, shapes: Matter.Body[]) => {
    if (!render?.mouse?.position) return;

    // Get mouse position in render coordinates
    const mouse = render.mouse.position;
    
    // Query for bodies at mouse position
    const bodies = Query.point(shapes, mouse);
    const hoveredShape = bodies.find(body => !body.isStatic);

    if (hoveredShape) {
      render.canvas.style.cursor = 'pointer';
      setHoveredBody({
        position: hoveredShape.position,
        velocity: hoveredShape.velocity,
        angularVelocity: hoveredShape.angularVelocity,
        speed: Vector.magnitude(hoveredShape.velocity),
        mass: hoveredShape.mass
      });
    } else {
      render.canvas.style.cursor = 'default';
      setHoveredBody(null);
    }
  };

  const resetStats = (canvas: HTMLCanvasElement) => {
    canvas.style.cursor = 'default';
    setHoveredBody(null);
  };

  return { hoveredBody, updateStats, resetStats };
}
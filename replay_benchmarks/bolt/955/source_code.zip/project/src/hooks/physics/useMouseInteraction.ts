import { Body, Vector } from 'matter-js';
import { WORLD_SIZE, DISPLAY_SIZE } from '../../utils/constants';

export function setupMouseInteraction(mouseConstraint: Matter.MouseConstraint) {
  if (!mouseConstraint || !mouseConstraint.mouse) return;
  
  const scale = WORLD_SIZE / DISPLAY_SIZE;
  
  mouseConstraint.mousedown = () => {
    const clickedBody = mouseConstraint.body;
    if (clickedBody && !clickedBody.isStatic) {
      if (Math.abs(clickedBody.velocity.x) < 0.1 && Math.abs(clickedBody.velocity.y) < 0.1) {
        applyRandomVelocity(clickedBody);
      } else {
        stopBody(clickedBody);
      }
    }
  };

  // Update mouse scaling
  mouseConstraint.mouse.scale = Vector.create(scale, scale);
}

function applyRandomVelocity(body: Matter.Body) {
  const speed = Math.random() * 9.5 + 0.5;
  const angle = Math.random() * Math.PI * 2;
  Body.setVelocity(body, {
    x: speed * Math.cos(angle),
    y: speed * Math.sin(angle)
  });
}

function stopBody(body: Matter.Body) {
  Body.setVelocity(body, { x: 0, y: 0 });
  Body.setAngularVelocity(body, 0);
}
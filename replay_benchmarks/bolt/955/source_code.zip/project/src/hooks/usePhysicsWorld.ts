import { useEffect, useState, useCallback } from 'react';
import { Runner, Events, Render } from 'matter-js';
import { setupPhysicsWorld } from '../physics/world';
import { useStats } from './physics/useStats';
import { setupMouseInteraction } from './physics/useMouseInteraction';
import type { DebugInfo } from '../types/physics';
import { WORLD_SIZE, DISPLAY_SIZE } from '../utils/constants';

export function usePhysicsWorld(containerRef: React.RefObject<HTMLDivElement>) {
  const [world, setWorld] = useState<ReturnType<typeof setupPhysicsWorld> | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [debugMode, setDebugMode] = useState(false);
  const [debugInfo, setDebugInfo] = useState<DebugInfo>({ mousePosition: null });
  const { hoveredBody, updateStats, resetStats } = useStats();
  const [runner, setRunner] = useState<Matter.Runner | null>(null);

  const toggleSimulation = useCallback(() => {
    if (!world || !runner) return;
    
    if (isRunning) {
      Runner.stop(runner);
    } else {
      Runner.start(runner, world.engine);
    }
    setIsRunning(!isRunning);
  }, [isRunning, world, runner]);

  const toggleDebug = useCallback(() => {
    setDebugMode(prev => !prev);
  }, []);

  useEffect(() => {
    if (!containerRef.current) return;

    const physicsWorld = setupPhysicsWorld(containerRef.current);
    setWorld(physicsWorld);

    const { engine, render, shapes } = physicsWorld;
    const newRunner = Runner.create();
    setRunner(newRunner);

    const handleStats = () => {
      if (render?.mouse?.position) {
        const rect = render.canvas.getBoundingClientRect();
        const scale = WORLD_SIZE / DISPLAY_SIZE;
        
        // Convert screen coordinates to world coordinates
        const worldX = Math.round(render.mouse.position.x * scale);
        const worldY = Math.round(render.mouse.position.y * scale);

        setDebugInfo({
          mousePosition: {
            x: worldX,
            y: worldY
          }
        });
        updateStats(render, shapes);
      }
    };

    if (physicsWorld.mouseConstraint) {
      setupMouseInteraction(physicsWorld.mouseConstraint);
    }

    // Start render but not the simulation
    Render.run(render);

    Events.on(engine, 'afterUpdate', handleStats);
    render.canvas.addEventListener('mousemove', handleStats);
    render.canvas.addEventListener('mouseleave', () => {
      resetStats(render.canvas);
      setDebugInfo({ mousePosition: null });
    });

    return () => {
      Events.off(engine, 'afterUpdate', handleStats);
      render.canvas.removeEventListener('mousemove', handleStats);
      render.canvas.removeEventListener('mouseleave', () => resetStats(render.canvas));
      
      if (runner) {
        Runner.stop(runner);
      }
      
      if (world) {
        world.cleanup();
      }
    };
  }, [containerRef]);

  return { 
    hoveredBody,
    isRunning,
    debugMode,
    debugInfo,
    toggleSimulation,
    toggleDebug,
    world
  };
}
import React, { useRef } from 'react';
import { usePhysicsWorld } from './hooks/usePhysicsWorld';
import { DebugPanel } from './components/DebugPanel';
import { DISPLAY_SIZE } from './utils/constants';

function App() {
  const sceneRef = useRef<HTMLDivElement>(null);
  const { 
    hoveredBody, 
    isRunning,
    debugMode,
    debugInfo,
    toggleSimulation,
    toggleDebug,
    world
  } = usePhysicsWorld(sceneRef);

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center gap-8">
      <div className="relative">
        <div 
          ref={sceneRef} 
          className="rounded-lg shadow-lg overflow-hidden"
          style={{ width: DISPLAY_SIZE, height: DISPLAY_SIZE }}
        />
        {debugMode && world?.shapes.map((shape, index) => (
          <div
            key={index}
            className="absolute bg-black/50 text-white text-xs p-1 rounded pointer-events-none"
            style={{
              left: `${shape.position.x}px`,
              top: `${shape.position.y}px`,
              transform: 'translate(10px, -50%)'
            }}
          >
            ({Math.round(shape.position.x)}, {Math.round(shape.position.y)})
          </div>
        ))}
      </div>
      <DebugPanel 
        stats={hoveredBody}
        isRunning={isRunning}
        debugMode={debugMode}
        debugInfo={debugInfo}
        onToggleSimulation={toggleSimulation}
        onToggleDebug={toggleDebug}
      />
    </div>
  );
}

export default App;
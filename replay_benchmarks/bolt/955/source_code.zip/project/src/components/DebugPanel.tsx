import React from 'react';
import { Play, Pause, Bug } from 'lucide-react';
import type { PhysicsStats, DebugInfo } from '../types/physics';

interface DebugPanelProps {
  stats: PhysicsStats | null;
  isRunning: boolean;
  debugMode: boolean;
  debugInfo: DebugInfo;
  onToggleSimulation: () => void;
  onToggleDebug: () => void;
}

export function DebugPanel({ 
  stats, 
  isRunning, 
  debugMode, 
  debugInfo, 
  onToggleSimulation, 
  onToggleDebug 
}: DebugPanelProps) {
  return (
    <div className="w-80 bg-white p-4 rounded-lg shadow-lg h-[600px]">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Info Panel</h2>
        <div className="flex gap-2">
          <button
            onClick={onToggleSimulation}
            className="p-2 rounded-lg bg-blue-500 hover:bg-blue-600 text-white transition-colors"
            title={isRunning ? "Stop Simulation" : "Start Simulation"}
          >
            {isRunning ? <Pause size={20} /> : <Play size={20} />}
          </button>
          <button
            onClick={onToggleDebug}
            className={`p-2 rounded-lg transition-colors ${
              debugMode 
                ? 'bg-purple-500 hover:bg-purple-600 text-white' 
                : 'bg-gray-200 hover:bg-gray-300'
            }`}
            title="Toggle Debug Mode"
          >
            <Bug size={20} />
          </button>
        </div>
      </div>

      {debugMode && (
        <div className="bg-gray-50 p-2 rounded mb-4 text-sm font-mono">
          <p className="font-medium text-gray-700">Mouse Position</p>
          {debugInfo.mousePosition ? (
            <div className="grid grid-cols-2 gap-x-2">
              <span>X: {debugInfo.mousePosition.x}</span>
              <span>Y: {debugInfo.mousePosition.y}</span>
            </div>
          ) : (
            <p className="text-gray-500 italic">Move mouse over canvas</p>
          )}
        </div>
      )}

      {stats ? (
        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded">
            <h3 className="font-medium mb-2">Position</h3>
            <p>X: {stats.position.x.toFixed(2)}</p>
            <p>Y: {stats.position.y.toFixed(2)}</p>
          </div>
          
          <div className="bg-gray-50 p-4 rounded">
            <h3 className="font-medium mb-2">Velocity</h3>
            <p>X: {stats.velocity.x.toFixed(2)}</p>
            <p>Y: {stats.velocity.y.toFixed(2)}</p>
            <p className="mt-1">Speed: {stats.speed.toFixed(2)}</p>
          </div>
          
          <div className="bg-gray-50 p-4 rounded">
            <h3 className="font-medium mb-2">Other Properties</h3>
            <p>Angular Velocity: {stats.angularVelocity.toFixed(2)}</p>
            <p>Mass: {stats.mass.toFixed(2)}</p>
          </div>
        </div>
      ) : (
        <p className="text-gray-500 italic">Hover over an object to see its physics stats</p>
      )}
    </div>
  );
}
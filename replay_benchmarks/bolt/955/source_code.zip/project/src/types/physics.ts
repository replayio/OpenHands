import { Body } from 'matter-js';

export interface PhysicsStats {
  position: { x: number; y: number };
  velocity: { x: number; y: number };
  angularVelocity: number;
  speed: number;
  mass: number;
}

export interface PhysicsWorld {
  engine: Matter.Engine;
  render: Matter.Render;
  shapes: Body[];
  mouseConstraint: Matter.MouseConstraint;
  cleanup: () => void;
}

export interface DebugInfo {
  mousePosition: { x: number; y: number } | null;
}
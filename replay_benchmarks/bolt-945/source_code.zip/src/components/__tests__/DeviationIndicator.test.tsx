import { render, screen } from '@testing-library/react';
import { DeviationIndicator } from '../DeviationIndicator';

describe('DeviationIndicator', () => {
  it('shows minus icon for small deviations', () => {
    render(<DeviationIndicator deviation={2} />);
    expect(screen.getByTestId('minus')).toBeInTheDocument();
  });

  it('shows up arrow for positive deviations', () => {
    render(<DeviationIndicator deviation={10} />);
    expect(screen.getByTestId('arrow-up-right')).toBeInTheDocument();
  });

  it('shows down arrow for negative deviations', () => {
    render(<DeviationIndicator deviation={-10} />);
    expect(screen.getByTestId('arrow-down-right')).toBeInTheDocument();
  });
});

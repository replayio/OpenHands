import React from 'react';
import { NetworkRequest } from '../types/performance';
import { DeviationIndicator } from './DeviationIndicator';
import { calculateNetworkStats } from '../utils/network';
import { calculateDeviation, formatDeviation, formatBytes } from '../utils/metrics';

interface NetworkStatsProps {
  requests: NetworkRequest[];
  medianValues: {
    networkStats: {
      totalBytes: number;
      byExtension: Record<string, number>;
    };
  };
}

export function NetworkStats({ requests, medianValues }: NetworkStatsProps) {
  const stats = calculateNetworkStats(requests);
  const totalBytesDeviation = calculateDeviation(
    stats.total.bytes,
    medianValues.networkStats.totalBytes
  );

  return (
    <div>
      <h3 className="text-sm font-medium text-gray-500">Network Data</h3>
      <div className="mt-2 space-y-4">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Total Data Transferred:</span>
          <span className="flex items-center gap-2">
            {formatBytes(stats.total.bytes)}
            <DeviationIndicator deviation={totalBytesDeviation} />
            <span className="text-sm text-gray-500">
              {formatDeviation(totalBytesDeviation)}
            </span>
          </span>
        </div>

        <div className="space-y-2">
          <h4 className="text-xs font-medium text-gray-400">By File Type</h4>
          {Object.entries(stats.byExtension)
            .sort((a, b) => b[1].bytes - a[1].bytes)
            .map(([ext, { requests: reqCount, bytes }]) => {
              const deviation = calculateDeviation(
                bytes,
                medianValues.networkStats.byExtension[ext] || bytes
              );
              
              return (
                <div key={ext} className="flex justify-between text-sm">
                  <span className="text-gray-600">
                    .{ext} ({reqCount} request{reqCount !== 1 ? 's' : ''})
                  </span>
                  <span className="flex items-center gap-2">
                    {formatBytes(bytes)}
                    <DeviationIndicator deviation={deviation} />
                    <span className="text-sm text-gray-500">
                      {formatDeviation(deviation)}
                    </span>
                  </span>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import { useParams } from 'react-router-dom';
import { usePerformanceData } from '../hooks/usePerformanceData';
import { SummaryCard } from './SummaryCard';
import { calculateMedianValues } from '../utils/performance';
import { getInteractionTitle } from '../utils/interaction';
import { AlertCircle, Loader2 } from 'lucide-react';

export function PerformanceView() {
  const { recordingId } = useParams<{ recordingId: string }>();
  const { performanceData, mainBranchRuns, loading, error } = usePerformanceData(recordingId!);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
      </div>
    );
  }

  if (error || !performanceData) {
    return (
      <div className="flex items-center justify-center min-h-screen text-red-500">
        <AlertCircle className="w-6 h-6 mr-2" />
        <span>{error || 'Failed to load performance data'}</span>
      </div>
    );
  }

  const medianValues = calculateMedianValues(mainBranchRuns);
  const { metadata } = performanceData.analysisResult.spec;
  const { requests, summaries } = performanceData.analysisResult;

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Performance Analysis
          </h1>
          <div className="text-sm text-gray-500">
            <p>Repository: {metadata.repo}</p>
            <p>Branch: {metadata.branch}</p>
            <p>Test: {metadata.testTitle}</p>
            <p>Commit: {metadata.commit.substring(0, 7)}</p>
          </div>
        </div>

        <div className="space-y-8">
          {summaries.map((summary, index) => (
            <div key={`${summary.startTime}-${index}`}>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                {getInteractionTitle(summary.origin)}
              </h2>
              <SummaryCard 
                summary={summary}
                requests={requests}
                medianValues={medianValues}
                isFirstInteraction={index === 0}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import { DeviationIndicator } from './DeviationIndicator';
import { calculateDeviation, formatDeviation } from '../utils/metrics';

interface NetworkRoundTripsProps {
  roundTrips: number;
  medianRoundTrips: number;
}

export function NetworkRoundTrips({ roundTrips, medianRoundTrips }: NetworkRoundTripsProps) {
  const roundTripDeviation = calculateDeviation(roundTrips, medianRoundTrips);

  return (
    <div className="flex justify-between text-sm">
      <span className="text-gray-500 font-medium">Network Round Trips:</span>
      <span className="flex items-center gap-2">
        {roundTrips}
        <DeviationIndicator deviation={roundTripDeviation} />
        <span className="text-sm text-gray-500">
          {formatDeviation(roundTripDeviation)}
        </span>
      </span>
    </div>
  );
}

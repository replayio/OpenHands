import React from 'react';
import { ArrowDownRight, ArrowUpRight, Minus } from 'lucide-react';

interface DeviationIndicatorProps {
  deviation: number;
}

export function DeviationIndicator({ deviation }: DeviationIndicatorProps) {
  if (Math.abs(deviation) < 5) {
    return <Minus className="inline w-4 h-4 text-gray-500" />;
  }
  return deviation > 0 ? (
    <ArrowUpRight className="inline w-4 h-4 text-red-500" />
  ) : (
    <ArrowDownRight className="inline w-4 h-4 text-green-500" />
  );
}

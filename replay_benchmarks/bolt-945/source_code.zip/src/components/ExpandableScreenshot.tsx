import React, { useState } from 'react';
import { Maximize2, Minimize2 } from 'lucide-react';

interface ExpandableScreenshotProps {
  imageData: string;
  originalWidth: number;
  originalHeight: number;
}

export function ExpandableScreenshot({ imageData, originalWidth, originalHeight }: ExpandableScreenshotProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const toggleExpand = () => setIsExpanded(!isExpanded);

  const aspectRatio = originalWidth / originalHeight;
  const baseWidth = isExpanded ? 'w-full' : 'w-64';

  return (
    <div className="relative group">
      <img
        src={`data:image/png;base64,${imageData}`}
        alt="Interaction screenshot"
        className={`${baseWidth} h-auto rounded-lg transition-all duration-300 cursor-pointer`}
        style={{ aspectRatio }}
        onClick={toggleExpand}
      />
      <button
        onClick={toggleExpand}
        className="absolute top-2 right-2 p-1 bg-black/50 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
      >
        {isExpanded ? (
          <Minimize2 className="w-4 h-4" />
        ) : (
          <Maximize2 className="w-4 h-4" />
        )}
      </button>
    </div>
  );
}

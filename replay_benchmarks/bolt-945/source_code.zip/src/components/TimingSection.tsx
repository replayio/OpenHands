import React from 'react';
import { Summary } from '../types/performance';
import { TimingItem } from './TimingItem';
import { ReactTimings } from './ReactTimings';

interface TimingSectionProps {
  summary: Summary;
  medianValues: {
    elapsed: number;
    networkTime: number;
    mainThreadTime: number;
    schedulingTime: number;
    workerThreadTime?: number;
    timerTime?: number;
    unknownTime?: number;
    reactSliceTime?: Record<string, number>;
    reactEventTime?: Record<string, number>;
  };
}

export function TimingSection({ summary, medianValues }: TimingSectionProps) {
  return (
    <div>
      <h3 className="text-sm font-medium text-gray-500">Timing Information</h3>
      <div className="mt-2 space-y-4">
        <div className="space-y-2">
          <h4 className="text-xs font-medium text-gray-400">Main Timings</h4>
          <ul className="space-y-2">
            <TimingItem
              label="Total Time"
              value={summary.elapsed}
              median={medianValues.elapsed}
              unit="ms"
            />
            <TimingItem
              label="Network Time"
              value={summary.networkTime}
              median={medianValues.networkTime}
              unit="ms"
            />
            <TimingItem
              label="Main Thread Time"
              value={summary.mainThreadTime}
              median={medianValues.mainThreadTime}
              unit="ms"
            />
            <TimingItem
              label="Scheduling Time"
              value={summary.schedulingTime}
              median={medianValues.schedulingTime}
              unit="ms"
            />
            <TimingItem
              label="Worker Thread Time"
              value={summary.workerThreadTime}
              median={medianValues.workerThreadTime}
              unit="ms"
            />
            <TimingItem
              label="Timer Time"
              value={summary.timerTime}
              median={medianValues.timerTime}
              unit="ms"
            />
            <TimingItem
              label="Unknown Time"
              value={summary.unknownTime}
              median={medianValues.unknownTime}
              unit="ms"
            />
          </ul>
        </div>

        <ReactTimings
          sliceTimes={summary.reactSliceTime}
          eventTimes={summary.reactEventTime}
          medianSliceTimes={medianValues.reactSliceTime}
          medianEventTimes={medianValues.reactEventTime}
        />
      </div>
    </div>
  );
}

import React from 'react';
import { Summary, NetworkRequest } from '../types/performance';
import { ExpandableScreenshot } from './ExpandableScreenshot';
import { TimingSection } from './TimingSection';
import { NetworkStats } from './NetworkStats';
import { NetworkRoundTrips } from './NetworkRoundTrips';

interface SummaryCardProps {
  summary: Summary;
  requests: NetworkRequest[];
  medianValues: {
    networkTime: number;
    mainThreadTime: number;
    schedulingTime: number;
    numNetworkRoundTrips: number;
    networkStats: {
      totalBytes: number;
      byExtension: Record<string, number>;
    };
  };
  isFirstInteraction: boolean;
}

export function SummaryCard({ summary, requests, medianValues, isFirstInteraction }: SummaryCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-8">
      <div className="mb-6">
        <ExpandableScreenshot 
          imageData={summary.commitScreenShot.screen}
          originalWidth={summary.commitScreenShot.originalWidth}
          originalHeight={summary.commitScreenShot.originalHeight}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <TimingSection summary={summary} medianValues={medianValues} />
        <div className="space-y-8">
          <NetworkRoundTrips 
            roundTrips={summary.numNetworkRoundTrips}
            medianRoundTrips={medianValues.numNetworkRoundTrips}
          />
          {isFirstInteraction && (
            <NetworkStats 
              requests={requests}
              medianValues={medianValues}
            />
          )}
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import { TimingItem } from './TimingItem';

interface ReactTimingsProps {
  sliceTimes?: Record<string, number>;
  eventTimes?: Record<string, number>;
  medianSliceTimes?: Record<string, number>;
  medianEventTimes?: Record<string, number>;
}

export function ReactTimings({ 
  sliceTimes, 
  eventTimes,
  medianSliceTimes = {},
  medianEventTimes = {}
}: ReactTimingsProps) {
  if (!sliceTimes && !eventTimes) return null;

  return (
    <>
      {sliceTimes && (
        <div className="space-y-2">
          <h4 className="text-xs font-medium text-gray-400">React Slice Timings</h4>
          <ul className="space-y-2">
            {Object.entries(sliceTimes).map(([key, value]) => (
              <TimingItem
                key={key}
                label={key}
                value={value}
                median={medianSliceTimes[key]}
                unit="ms"
              />
            ))}
          </ul>
        </div>
      )}

      {eventTimes && (
        <div className="space-y-2">
          <h4 className="text-xs font-medium text-gray-400">React Event Timings</h4>
          <ul className="space-y-2">
            {Object.entries(eventTimes).map(([key, value]) => (
              <TimingItem
                key={key}
                label={key}
                value={value}
                median={medianEventTimes[key]}
                unit="ms"
              />
            ))}
          </ul>
        </div>
      )}
    </>
  );
}

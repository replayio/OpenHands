import React from 'react';
import { DeviationIndicator } from './DeviationIndicator';
import { calculateDeviation, formatDeviation } from '../utils/metrics';

interface TimingItemProps {
  label: string;
  value: number;
  median?: number;
  unit?: string;
}

export function TimingItem({ label, value, median, unit = '' }: TimingItemProps) {
  const hasDeviation = median !== undefined;
  const deviation = hasDeviation ? calculateDeviation(value, median) : undefined;

  return (
    <li className="flex justify-between text-sm">
      <span className="text-gray-600">{label}:</span>
      <span className="flex items-center gap-2">
        <span>{value.toFixed(2)}{unit}</span>
        {hasDeviation && (
          <>
            <DeviationIndicator deviation={deviation!} />
            <span className="text-sm text-gray-500">
              {formatDeviation(deviation!)}
            </span>
          </>
        )}
      </span>
    </li>
  );
}

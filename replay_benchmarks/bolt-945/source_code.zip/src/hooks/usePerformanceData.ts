import { useState, useEffect } from 'react';
import { PerformanceData, WorkspaceData, Summary } from '../types/performance';
import { fetchPerformanceData, fetchWorkspaceData, fetchMainBranchRuns } from '../utils/api';

export function usePerformanceData(recordingId: string) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [performanceData, setPerformanceData] = useState<PerformanceData | null>(null);
  const [mainBranchRuns, setMainBranchRuns] = useState<Summary[][]>([]);

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        
        // Fetch performance data for current recording
        const perfData = await fetchPerformanceData(recordingId);
        setPerformanceData(perfData);
        
        // Fetch workspace data
        const workspaceId = perfData.analysisResult.spec.metadata.workspaceId;
        const workspaceData = await fetchWorkspaceData(workspaceId);
        
        // Get main branch runs
        const runs = await fetchMainBranchRuns(workspaceData, perfData);
        setMainBranchRuns(runs);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load performance data');
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [recordingId]);

  return { performanceData, mainBranchRuns, loading, error };
}

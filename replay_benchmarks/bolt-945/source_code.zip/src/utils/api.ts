import { PerformanceData, WorkspaceData, Summary } from '../types/performance';

export async function fetchPerformanceData(recordingId: string): Promise<PerformanceData> {
  const response = await fetch(
    `https://corsproxy.io/?url=https://static.replay.io/performance/performance-v3-v5-${recordingId}.json`
  );
  
  if (!response.ok) {
    throw new Error('Failed to fetch performance data');
  }
  
  return response.json();
}

export async function fetchWorkspaceData(workspaceId: string): Promise<WorkspaceData[]> {
  const response = await fetch(
    `https://corsproxy.io/?url=https://static.replay.io/performance/workspaces/${workspaceId}/workspace-performance-v1-v3-v5-v12.json`
  );
  
  if (!response.ok) {
    throw new Error('Failed to fetch workspace data');
  }
  
  return response.json();
}

export async function fetchMainBranchRuns(
  workspaceData: WorkspaceData[],
  currentRecording: PerformanceData
): Promise<Summary[][]> {
  const currentTimestamp = new Date(workspaceData.find(
    data => data.recordingId === currentRecording.analysisResult.spec.recordingId
  )?.timestamp || '');

  const mainBranchRecordings = workspaceData
    .filter(data => 
      data.metadata.branch === 'main' && 
      new Date(data.timestamp) < currentTimestamp
    )
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 5);

  const runs = await Promise.all(
    mainBranchRecordings.map(async recording => {
      const data = await fetchPerformanceData(recording.recordingId);
      return data.analysisResult.summaries;
    })
  );

  return runs;
}

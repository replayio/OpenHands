export function calculateDeviation(value: number, median: number): number {
  if (typeof value !== 'number' || typeof median !== 'number') return 0;
  if (median === 0) {
    // If median is 0 but we have a value, show 100% increase
    return value > 0 ? 100 : 0;
  }
  return ((value - median) / median) * 100;
}

export function formatDeviation(deviation: number): string {
  if (!isFinite(deviation) || isNaN(deviation)) return '0.0%';
  const sign = deviation > 0 ? '+' : '';
  return `${sign}${deviation.toFixed(1)}%`;
}

export function formatBytes(bytes: number): string {
  if (typeof bytes !== 'number' || bytes < 0) return '0.0 B';
  
  const units = ['B', 'KB', 'MB', 'GB'];
  let size = bytes;
  let unitIndex = 0;
  
  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }
  
  return `${size.toFixed(1)} ${units[unitIndex]}`;
}

import { DependencyChainOrigin } from '../types/performance';

export function getInteractionTitle(origin: DependencyChainOrigin): string {
  switch (origin.kind) {
    case 'documentLoad':
      return 'Initial Page Load';
    case 'dispatchEvent':
      return `User Event: ${origin.eventType || 'Unknown Event'}`;
    case 'resize':
      return 'Window Resize';
    case 'other':
      return 'Other Interaction';
    default:
      return 'Unknown Interaction';
  }
}

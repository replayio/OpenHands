import { describe, it, expect } from 'vitest';
import { calculateDeviation, formatDeviation, formatBytes } from '../metrics';

describe('metrics utils', () => {
  describe('calculateDeviation', () => {
    it('calculates positive deviation', () => {
      expect(calculateDeviation(110, 100)).toBe(10);
    });

    it('calculates negative deviation', () => {
      expect(calculateDeviation(90, 100)).toBe(-10);
    });

    it('returns 0 for equal values', () => {
      expect(calculateDeviation(100, 100)).toBe(0);
    });

    it('returns 0 for zero median', () => {
      expect(calculateDeviation(100, 0)).toBe(0);
    });
  });

  describe('formatDeviation', () => {
    it('formats positive deviation', () => {
      expect(formatDeviation(10.5)).toBe('+10.5%');
    });

    it('formats negative deviation', () => {
      expect(formatDeviation(-10.5)).toBe('-10.5%');
    });

    it('formats zero deviation', () => {
      expect(formatDeviation(0)).toBe('0.0%');
    });
  });

  describe('formatBytes', () => {
    it('formats bytes', () => {
      expect(formatBytes(500)).toBe('500.0 B');
    });

    it('formats kilobytes', () => {
      expect(formatBytes(1500)).toBe('1.5 KB');
    });

    it('formats megabytes', () => {
      expect(formatBytes(1500000)).toBe('1.4 MB');
    });

    it('formats gigabytes', () => {
      expect(formatBytes(1500000000)).toBe('1.4 GB');
    });

    it('handles zero', () => {
      expect(formatBytes(0)).toBe('0.0 B');
    });

    it('handles negative values', () => {
      expect(formatBytes(-100)).toBe('0.0 B');
    });
  });
});

import { Summary, NetworkRequest } from '../types/performance';
import { calculateNetworkStats } from './network';
import { getMedian } from './stats';

export function calculateMedianValues(mainBranchRuns: Summary[][]) {
  if (!mainBranchRuns?.length) {
    return getDefaultMedianValues();
  }

  const allValues = mainBranchRuns.flatMap(run => run[0]);

  // Calculate network stats for each run
  const networkStats = allValues.map(summary => calculateNetworkStats(summary.requests));

  // Get all unique extensions
  const allExtensions = new Set(
    networkStats.flatMap(stats => Object.keys(stats.byExtension))
  );

  // Calculate median bytes for each extension
  const byExtension: Record<string, number> = {};
  allExtensions.forEach(ext => {
    const bytesForExt = networkStats.map(stats => stats.byExtension[ext]?.bytes || 0);
    if (bytesForExt.some(bytes => bytes > 0)) {
      byExtension[ext] = getMedian(bytesForExt);
    }
  });

  return {
    elapsed: getMedian(allValues.map(s => s.elapsed)),
    networkTime: getMedian(allValues.map(s => s.networkTime)),
    mainThreadTime: getMedian(allValues.map(s => s.mainThreadTime)),
    schedulingTime: getMedian(allValues.map(s => s.schedulingTime)),
    workerThreadTime: getMedian(allValues.map(s => s.workerThreadTime || 0)),
    timerTime: getMedian(allValues.map(s => s.timerTime || 0)),
    unknownTime: getMedian(allValues.map(s => s.unknownTime || 0)),
    numNetworkRoundTrips: getMedian(allValues.map(s => s.numNetworkRoundTrips)),
    networkStats: {
      totalBytes: getMedian(networkStats.map(s => s.total.bytes)),
      byExtension
    },
    reactSliceTime: calculateMedianTimings(allValues.map(s => s.reactSliceTime)),
    reactEventTime: calculateMedianTimings(allValues.map(s => s.reactEventTime))
  };
}

function calculateMedianTimings(timings: (Record<string, number> | undefined)[]): Record<string, number> {
  const allKeys = new Set(timings.flatMap(t => t ? Object.keys(t) : []));
  const result: Record<string, number> = {};

  allKeys.forEach(key => {
    const values = timings
      .map(t => t?.[key])
      .filter((v): v is number => typeof v === 'number');
    if (values.length > 0) {
      result[key] = getMedian(values);
    }
  });

  return result;
}

function getDefaultMedianValues() {
  return {
    elapsed: 0,
    networkTime: 0,
    mainThreadTime: 0,
    schedulingTime: 0,
    workerThreadTime: 0,
    timerTime: 0,
    unknownTime: 0,
    numNetworkRoundTrips: 0,
    networkStats: {
      totalBytes: 0,
      byExtension: {}
    },
    reactSliceTime: {},
    reactEventTime: {}
  };
}

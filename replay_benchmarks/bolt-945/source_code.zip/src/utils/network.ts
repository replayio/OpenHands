import { NetworkRequest, NetworkStats } from '../types/performance';

const KNOWN_EXTENSIONS = new Set([
  'js', 'jsx', 'ts', 'tsx',
  'css', 'scss', 'sass', 'less',
  'html', 'htm',
  'json',
  'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp',
  'woff', 'woff2', 'ttf', 'eot', 'otf',
  'mp4', 'webm', 'ogg',
  'mp3', 'wav',
  'pdf', 'doc', 'docx',
  'zip', 'tar', 'gz'
]);

function getExtension(url: string): string {
  try {
    const urlObj = new URL(url);
    const pathname = urlObj.pathname;
    const ext = pathname.split('.').pop()?.toLowerCase() || '';
    
    // Handle source maps separately
    if (ext === 'map') {
      const baseExt = pathname.slice(0, -4).split('.').pop()?.toLowerCase();
      return baseExt ? `${baseExt}.map` : 'other';
    }
    
    return KNOWN_EXTENSIONS.has(ext) ? ext : 'other';
  } catch {
    return 'other';
  }
}

export function calculateNetworkStats(requests: NetworkRequest[]): NetworkStats {
  const stats: NetworkStats = {
    byExtension: {},
    total: { requests: 0, bytes: 0 }
  };

  if (!Array.isArray(requests)) return stats;

  requests.forEach(request => {
    if (!request?.url) return;

    const extension = getExtension(request.url);
    const totalBytes = (request.sentBytes || 0) + (request.receivedBytes || 0);

    // Initialize extension stats if needed
    if (!stats.byExtension[extension]) {
      stats.byExtension[extension] = { requests: 0, bytes: 0 };
    }

    // Update extension stats
    stats.byExtension[extension].requests++;
    stats.byExtension[extension].bytes += totalBytes;

    // Update total stats
    stats.total.requests++;
    stats.total.bytes += totalBytes;
  });

  return stats;
}

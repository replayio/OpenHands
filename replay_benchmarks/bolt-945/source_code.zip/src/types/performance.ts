export interface NetworkStats {
  byExtension: Record<string, {
    requests: number;
    bytes: number;
  }>;
  total: {
    requests: number;
    bytes: number;
  };
}

export interface NetworkRequest {
  url: string;
  time: number;
  point: string;
  sentBytes: number;
  receivedBytes: number;
}

export interface Summary {
  elapsed: number;
  networkTime: number;
  mainThreadTime: number;
  schedulingTime: number;
  workerThreadTime?: number;
  timerTime?: number;
  unknownTime?: number;
  numNetworkRoundTrips: number;
  reactSliceTime?: Record<string, number>;
  reactEventTime?: Record<string, number>;
  requests: NetworkRequest[];
  origin: DependencyChainOrigin;
  commitScreenShot: {
    screen: string;
    originalWidth: number;
    originalHeight: number;
  };
}

export interface DependencyChainOrigin {
  kind: 'documentLoad' | 'dispatchEvent' | 'resize' | 'other';
  eventType?: string;
}

export interface PerformanceData {
  version: number;
  result: string;
  analysisResult: {
    spec: {
      recordingId: string;
      metadata: {
        workspaceId: string;
        testTitle: string;
        repo: string;
        branch: string;
        commit: string;
      };
    };
    summaries: Summary[];
    requests: NetworkRequest[];
    recordingURL: string;
  };
}

export interface WorkspaceData {
  recordingId: string;
  timestamp: string;
  metadata: {
    branch: string;
  };
}

import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { PerformanceView } from './components/PerformanceView';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/recording/:recordingId" element={<PerformanceView />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

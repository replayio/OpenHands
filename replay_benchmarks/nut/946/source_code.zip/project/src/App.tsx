import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { Settings as SettingsIcon, MessageSquare } from 'lucide-react';
import { ModelConfig } from './components/ModelConfig';
import { Settings } from './components/Settings';
import { useAPIKeys } from './store/apiKeys';
import { generateCompletion } from './services/llm';
import type { LLMConfig, ComparisonResult } from './types';

function Comparison() {
  const { keys } = useAPIKeys();
  const [configs, setConfigs] = useState<LLMConfig[]>([
    { provider: 'openai', model: 'gpt-4-turbo-preview', temperature: 0.7 },
    { provider: 'anthropic', model: 'claude-3-opus-20240229', temperature: 0.7 },
  ]);
  const [prompt, setPrompt] = useState('');
  const [results, setResults] = useState<ComparisonResult[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setLoading(true);
    const newResults: ComparisonResult[] = [];

    try {
      await Promise.all(
        configs.map(async (config) => {
          const apiKey = keys[config.provider];
          if (!apiKey) {
            newResults.push({
              id: Math.random().toString(36).substring(7),
              config,
              response: '',
              error: `No API key set for ${config.provider}`,
              timing: 0,
            });
            return;
          }

          const startTime = Date.now();
          try {
            const response = await generateCompletion(config, prompt, apiKey);
            newResults.push({
              id: Math.random().toString(36).substring(7),
              config,
              response,
              timing: Date.now() - startTime,
            });
          } catch (error) {
            newResults.push({
              id: Math.random().toString(36).substring(7),
              config,
              response: '',
              error: error instanceof Error ? error.message : 'Unknown error',
              timing: Date.now() - startTime,
            });
          }
        })
      );
    } finally {
      setResults(newResults);
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-6 flex justify-between items-center">
        <h1 className="text-2xl font-bold">LLM Comparison</h1>
        <Link
          to="/settings"
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
        >
          <SettingsIcon className="w-5 h-5" />
          Settings
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {configs.map((config, index) => (
          <ModelConfig
            key={index}
            config={config}
            onChange={(newConfig) => {
              const newConfigs = [...configs];
              newConfigs[index] = newConfig;
              setConfigs(newConfigs);
            }}
          />
        ))}
      </div>

      <form onSubmit={handleSubmit} className="mb-6">
        <div className="flex gap-4">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Enter your prompt here..."
            className="flex-1 p-4 border rounded-lg min-h-[100px]"
          />
          <button
            type="submit"
            disabled={loading || !prompt.trim()}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? 'Generating...' : 'Generate'}
          </button>
        </div>
      </form>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {results.map((result) => (
          <div
            key={result.id}
            className="bg-white rounded-lg shadow-md p-6 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">
                {result.config.provider} - {result.config.model}
              </h3>
              <span className="text-sm text-gray-500">{result.timing}ms</span>
            </div>
            {result.error ? (
              <div className="text-red-600">{result.error}</div>
            ) : (
              <div className="whitespace-pre-wrap">{result.response}</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-50">
        <Routes>
          <Route path="/" element={<Comparison />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
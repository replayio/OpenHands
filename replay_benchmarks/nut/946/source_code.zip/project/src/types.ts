export interface LLMConfig {
  provider: 'openai' | 'anthropic';
  model: string;
  temperature: number;
  seed?: number;
}

export interface ComparisonResult {
  id: string;
  config: LLMConfig;
  response: string;
  error?: string;
  timing: number;
}

export interface APIKeys {
  openai?: string;
  anthropic?: string;
}
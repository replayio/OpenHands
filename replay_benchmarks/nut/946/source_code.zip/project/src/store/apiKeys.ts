import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { APIKeys } from '../types';

interface APIKeysStore {
  keys: APIKeys;
  setKey: (provider: keyof APIKeys, key: string) => void;
}

export const useAPIKeys = create<APIKeysStore>()(
  persist(
    (set) => ({
      keys: {},
      setKey: (provider, key) =>
        set((state) => ({
          keys: { ...state.keys, [provider]: key },
        })),
    }),
    {
      name: 'api-keys',
    }
  )
);
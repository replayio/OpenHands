import OpenAI from 'openai';
import Anthropic from '@anthropic-ai/sdk';
import type { LLMConfig } from '../types';

export async function generateCompletion(
  config: LLMConfig,
  prompt: string,
  apiKey: string
): Promise<string> {
  if (!apiKey) {
    throw new Error(`No API key provided for ${config.provider}`);
  }

  try {
    if (config.provider === 'openai') {
      const openai = new OpenAI({ 
        apiKey,
        dangerouslyAllowBrowser: true
      });
      const response = await openai.chat.completions.create({
        model: config.model,
        messages: [{ role: 'user', content: prompt }],
        temperature: config.temperature,
        seed: config.seed,
      });
      return response.choices[0]?.message?.content || '';
    } else {
      const anthropic = new Anthropic({
        apiKey,
        baseURL: 'https://api.anthropic.com',
        httpAgent: undefined // Required for browser environment
      });
      
      const response = await anthropic.messages.create({
        model: config.model,
        max_tokens: 1024,
        messages: [{ role: 'user', content: prompt }],
        temperature: config.temperature,
      });
      
      return response.content[0]?.text || '';
    }
  } catch (error) {
    // Handle API-specific error messages
    if (error instanceof Error) {
      if (error.message.includes('401')) {
        throw new Error(`Invalid API key for ${config.provider}`);
      }
      if (error.message.includes('429')) {
        throw new Error(`Rate limit exceeded for ${config.provider}`);
      }
      throw new Error(`${config.provider} API error: ${error.message}`);
    }
    throw new Error(`Unexpected error when calling ${config.provider} API`);
  }
}
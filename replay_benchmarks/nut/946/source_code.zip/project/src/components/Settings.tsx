import React from 'react';
import { Key, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAPIKeys } from '../store/apiKeys';

export function Settings() {
  const { keys, setKey } = useAPIKeys();

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">API Settings</h1>
        <Link
          to="/"
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Comparison
        </Link>
      </div>
      
      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-2 mb-4">
            <Key className="w-5 h-5 text-gray-500" />
            <h2 className="text-lg font-semibold">OpenAI API Key</h2>
          </div>
          <input
            type="password"
            placeholder="sk-..."
            value={keys.openai || ''}
            onChange={(e) => setKey('openai', e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center gap-2 mb-4">
            <Key className="w-5 h-5 text-gray-500" />
            <h2 className="text-lg font-semibold">Anthropic API Key</h2>
          </div>
          <input
            type="password"
            placeholder="sk-ant-..."
            value={keys.anthropic || ''}
            onChange={(e) => setKey('anthropic', e.target.value)}
            className="w-full p-2 border rounded"
          />
        </div>
      </div>
    </div>
  );
}
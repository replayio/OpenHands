import React from 'react';
import { Settings2, Thermometer, Hash } from 'lucide-react';
import type { LLMConfig } from '../types';

const OPENAI_MODELS = ['gpt-4-turbo-preview', 'gpt-4', 'gpt-3.5-turbo'];
const ANTHROPIC_MODELS = ['claude-3-opus-20240229', 'claude-3-sonnet-20240229', 'claude-2.1'];

interface ModelConfigProps {
  config: LLMConfig;
  onChange: (config: LLMConfig) => void;
}

export function ModelConfig({ config, onChange }: ModelConfigProps) {
  const models = config.provider === 'openai' ? OPENAI_MODELS : ANTHROPIC_MODELS;

  return (
    <div className="bg-white rounded-lg shadow-md p-4 space-y-4">
      <div className="flex items-center gap-2">
        <Settings2 className="w-5 h-5 text-gray-500" />
        <select
          className="w-full p-2 border rounded"
          value={config.provider}
          onChange={(e) =>
            onChange({
              ...config,
              provider: e.target.value as 'openai' | 'anthropic',
              model: e.target.value === 'openai' ? OPENAI_MODELS[0] : ANTHROPIC_MODELS[0],
            })
          }
        >
          <option value="openai">OpenAI</option>
          <option value="anthropic">Anthropic</option>
        </select>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <select
            className="w-full p-2 border rounded"
            value={config.model}
            onChange={(e) => onChange({ ...config, model: e.target.value })}
          >
            {models.map((model) => (
              <option key={model} value={model}>
                {model}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <Thermometer className="w-5 h-5 text-gray-500" />
          <input
            type="range"
            min="0"
            max="2"
            step="0.1"
            value={config.temperature}
            onChange={(e) =>
              onChange({ ...config, temperature: parseFloat(e.target.value) })
            }
            className="w-full"
          />
          <span className="text-sm text-gray-600">{config.temperature}</span>
        </div>

        <div className="flex items-center gap-2">
          <Hash className="w-5 h-5 text-gray-500" />
          <input
            type="number"
            placeholder="Seed (optional)"
            value={config.seed || ''}
            onChange={(e) =>
              onChange({
                ...config,
                seed: e.target.value ? parseInt(e.target.value) : undefined,
              })
            }
            className="w-full p-2 border rounded"
          />
        </div>
      </div>
    </div>
  );
}
import React from 'react';
import { Code2, Play, Square } from 'lucide-react';

interface SampleInput {
  name: string;
  code: string;
}

interface CodeInputProps {
  code: string;
  onCodeChange: (code: string, parse?: boolean) => void;
  onParse: () => void;
  isRunning: boolean;
  onReset: () => void;
}

const SAMPLE_INPUTS: SampleInput[] = [
  { name: 'Simple If', code: 'var x = 5;\nif (x > 3) { print x }' },
  { name: 'Multi-line', code: 'var a = 10;\nif (a <= 10) {\n  print (a + 1);\n  a = (a + 1)\n}' },
  { name: 'Nested Ifs', code: 'var x = 1;\nif (x < 5) {\n  if (x > 0) {\n    print (x * 2)\n  }\n}' },
  { name: 'Assignment', code: 'var x = 1;\nx = (x + 1);\nprint x' },
  { name: 'Complex If', code: 'var n = 10;\nif (n >= 10) {\n  n = (n + 1);\n  print (n * 2)\n}' },
  { name: 'Comparison', code: 'var x = 2;\nif (x == 2) {\n  print (x * x)\n}' },
  { name: 'Mixed Ops', code: 'var n = 5;\nif (n != 0) {\n  print (n + (n * n))\n}' },
  { name: 'Variables', code: 'var x = 1;\nvar y = 2;\nif (x < y) {\n  x = (y * 2);\n  print x\n}' },
  { name: 'Function', code: 'function add(x, y) {\n  return x + y\n}\n\nvar a = 5;\nvar b = 3;\nprint add(a, b)' },
  { name: 'Simple Array', code: 'var nums = [1, 2, 3];\nprint nums[1]' },
  { name: 'Matrix', code: 'var matrix = [[1, 2], [3, 4]];\nprint matrix[1][0]' },
  { 
    name: 'Bubble Sort', 
    code: 'function swap(arr, i, j) {\n  var temp = arr[i];\n  arr[i] = arr[j];\n  arr[j] = temp;\n  return arr\n}\n\nfunction bubbleSort(arr) {\n  var n = arr.length;\n  var i = 0;\n  if (i < n - 1) {\n    if (arr[i] > arr[i + 1]) {\n      arr = swap(arr, i, i + 1)\n    };\n    i = i + 1\n  };\n  return arr\n}\n\nvar nums = [5, 3, 1, 4, 2];\nnums = bubbleSort(nums);\nprint nums[0]'
  }
];

export function CodeInput({ code, onCodeChange, onParse, isRunning, onReset }: CodeInputProps) {
  const loadSample = (sampleCode: string) => {
    onCodeChange(sampleCode, true);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 flex flex-col">
      <div className="mb-6">
        <h2 className="text-lg font-semibold text-gray-700 mb-3 flex items-center gap-2">
          <Code2 className="w-5 h-5" />
          Sample Inputs
        </h2>
        <div className="flex flex-wrap gap-2">
          {SAMPLE_INPUTS.map(sample => (
            <button
              key={sample.name}
              onClick={() => loadSample(sample.code)}
              className="px-3 py-1.5 bg-blue-50 text-blue-600 rounded-md hover:bg-blue-100 transition-colors"
            >
              {sample.name}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-col flex-1">
        <label htmlFor="code" className="block text-sm font-medium text-gray-700 mb-2">
          Code Input
        </label>
        <textarea
          id="code"
          value={code}
          onChange={(e) => onCodeChange(e.target.value)}
          className="w-full h-48 p-3 border rounded-md font-mono text-sm resize-vertical"
          placeholder="Enter code here..."
        />
      </div>

      <div className="mt-4">
        <button
          onClick={() => isRunning ? onReset() : onParse()}
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          {isRunning ? (
            <>
              <Square className="w-4 h-4 mr-2" />
              Stop
            </>
          ) : (
            <>
              <Play className="w-4 h-4 mr-2" />
              Parse
            </>
          )}
        </button>
      </div>
    </div>
  );
}
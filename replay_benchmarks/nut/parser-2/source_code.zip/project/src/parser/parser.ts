import { Token, ASTNode, ParserState, ParserContext } from './types';
import { parseProgram } from './parseProgram';
import { CodeRepresentation } from './CodeRepresentation';

export class Parser {
  private tokens: Token[];
  private context: ParserContext;
  private steps: {
    nodeName: string;
    node: ASTNode | null;
    position: number;
    line: number;
    code: string;
  }[];
  private currentStep: number;
  private lastAst: string | null;
  private codeRepresentation: CodeRepresentation;

  constructor(tokens: Token[], code: string) {
    this.codeRepresentation = new CodeRepresentation(code);
    this.tokens = tokens.filter(t => t.type !== 'whitespace');
    this.context = {
      tokens: this.tokens,
      current: 0,
      ast: null,
      parsingPhase: 'start',
      variables: new Set(),
      functions: new Set(),
      currentScope: { variables: new Set(), parent: null }
    };
    this.steps = [];
    this.currentStep = -1;
    this.lastAst = null;
  }

  private getCurrentPosition(): number {
    if (this.context.current >= this.tokens.length) {
      return this.codeRepresentation.getLastPosition();
    }
    return this.tokens[this.context.current]?.position || 0;
  }

  private addStep(nodeName: string, node: ASTNode | null) {
    const position = this.getCurrentPosition();
    const { line } = this.codeRepresentation.getLineAndColumn(position);
    const code = this.codeRepresentation.getAnnotatedLine(position);

    // Always add steps with nodeName, regardless of AST changes
    if (nodeName) {
      this.steps.push({ 
        nodeName, 
        node: node ? structuredClone(node) : null,
        position,
        line,
        code
      });
      if (node) {
        this.lastAst = JSON.stringify(node);
      }
      return;
    }

    // For steps without nodeName, only add if AST has changed
    const currentAst = node ? JSON.stringify(node) : null;
    if (currentAst !== this.lastAst) {
      this.steps.push({ 
        nodeName: '', 
        node: node ? structuredClone(node) : null,
        position,
        line,
        code
      });
      if (node) {
        this.lastAst = currentAst;
      }
    }
  }

  private parse(): void {
    try {
      const ast = parseProgram(this.tokens, 0, (nodeName, node) => {
        this.addStep(nodeName, node);
      });
      this.context.ast = ast;
      this.addStep('Parsing complete', ast);
    } catch (error) {
      const errorPosition = this.getCurrentPosition();
      const { line } = this.codeRepresentation.getLineAndColumn(errorPosition);
      const code = this.codeRepresentation.getAnnotatedLine(errorPosition);
      this.steps.push({
        nodeName: `Error: ${(error as Error).message}`,
        node: null,
        position: errorPosition,
        line,
        code
      });
      this.context.error = (error as Error).stack;
    }
  }

  public step(): ParserState {
    if (this.currentStep === -1) {
      this.parse();
    }
    
    this.currentStep++;

    if (this.currentStep >= this.steps.length) {
      const position = this.codeRepresentation.getLastPosition();
      const { line } = this.codeRepresentation.getLineAndColumn(position);
      const code = this.codeRepresentation.getAnnotatedLine(position);
      return {
        tokens: this.tokens,
        currentToken: this.context.current,
        ast: this.context.ast,
        error: null,
        errorStack: null,
        done: true,
        nodeName: 'Parsing complete',
        codeRepresentation: this.codeRepresentation,
        position,
        line,
        code
      };
    }

    const step = this.steps[this.currentStep];
    const isError = step.nodeName.startsWith('Error:');

    return {
      tokens: this.tokens,
      currentToken: this.context.current,
      ast: step.node,
      error: isError ? step.nodeName.slice(7) : null,
      errorStack: isError ? this.context.error : null,
      done: isError || this.currentStep === this.steps.length - 1,
      nodeName: isError ? undefined : step.nodeName,
      codeRepresentation: this.codeRepresentation,
      position: step.position,
      line: step.line,
      code: step.code
    };
  }
}
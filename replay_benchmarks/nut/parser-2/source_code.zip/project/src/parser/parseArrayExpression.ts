import { ArrayExpressionNode, ParserContext, ASTNode } from './types';
import { peek, consume } from './parserUtils';
import { parseExpression } from './parseExpression';

export function parseArrayExpression(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): ArrayExpressionNode {
  onStep('Array Expression: Start', null);

  // Consume opening bracket
  const openBracket = peek(context);
  if (!openBracket || openBracket.type !== 'bracket' || openBracket.value !== '[') {
    throw new Error('Expected [');
  }
  consume(context);

  const elements: ASTNode[] = [];
  const node: ArrayExpressionNode = {
    type: 'arrayExpression',
    elements: []
  };

  // Handle empty array
  const nextToken = peek(context);
  if (nextToken?.type === 'bracket' && nextToken.value === ']') {
    consume(context);
    onStep('Array Expression: Empty Array', node);
    return node;
  }

  while (context.current < context.tokens.length) {
    const token = peek(context);
    if (!token) break;

    if (token.type === 'bracket' && token.value === ']') {
      consume(context);
      node.elements = elements;
      onStep('Array Expression: Complete', node);
      return node;
    }

    if (token.type === 'comma') {
      consume(context);
      continue;
    }

    const element = parseExpression(context, onStep);
    elements.push(element);
    node.elements = [...elements];
    onStep('Array Expression: Element Added', node);
  }

  throw new Error('Expected ]');
}
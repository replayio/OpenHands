import { Token, ParserContext, ParserState, Scope } from './types';
import { CodeRepresentation } from './CodeRepresentation';

export interface Token {
  type: 'number' | 'operator' | 'paren' | 'print' | 'whitespace' | 'separator' | 'var' | 'identifier' | 'equals' | 'if' | 'comparison' | 'brace' | 'function' | 'comma' | 'return' | 'bracket' | 'dot';
  value: string;
  position: number;
}

export interface Scope {
  variables: Set<string>;
  parent: Scope | null;
}

export interface ParserContext {
  tokens: Token[];
  current: number;
  ast: ASTNode | null;
  parsingPhase: 'start' | 'statement' | 'expression' | 'term' | 'number' | 'complete';
  currentScope: Scope;
  functions: Set<string>;
}

export interface ParserState {
  tokens: Token[];
  currentToken: number;
  ast: ASTNode | null;
  error: string | null;
  errorStack?: string | null;
  done: boolean;
  nodeName?: string;
  codeRepresentation: CodeRepresentation;
  position: number;
  line: number;
  code: string;
}

interface BaseNode {
  type: string;
}

export interface NumberNode extends BaseNode {
  type: 'number';
  value: number;
}

export interface BinaryNode extends BaseNode {
  type: 'addition' | 'multiplication' | 'subtraction';
  left: ASTNode;
  right: ASTNode;
}

export interface PrintNode extends BaseNode {
  type: 'print';
  argument: ASTNode;
}

export interface GroupNode extends BaseNode {
  type: 'group';
  expression: ASTNode;
}

export interface VarDeclarationNode extends BaseNode {
  type: 'varDeclaration';
  name: string;
  initializer: ASTNode;
}

export interface IdentifierNode extends BaseNode {
  type: 'identifier';
  name: string;
}

export interface AssignmentNode extends BaseNode {
  type: 'assignment';
  target: ASTNode;
  value: ASTNode;
}

export interface ComparisonNode extends BaseNode {
  type: 'comparison';
  operator: '<' | '>' | '<=' | '>=' | '==' | '!=';
  left: ASTNode;
  right: ASTNode;
}

export interface IfNode extends BaseNode {
  type: 'if';
  condition: ASTNode;
  consequent: BlockNode;
}

export interface BlockNode extends BaseNode {
  type: 'block';
  statements: ASTNode[];
}

export interface FunctionDeclarationNode extends BaseNode {
  type: 'functionDeclaration';
  name: string;
  params: string[];
  body: BlockNode;
}

export interface FunctionCallNode extends BaseNode {
  type: 'functionCall';
  callee: string;
  arguments: ASTNode[];
}

export interface ReturnNode extends BaseNode {
  type: 'return';
  argument: ASTNode | null;
}

export interface ArrayExpressionNode extends BaseNode {
  type: 'arrayExpression';
  elements: ASTNode[];
}

export interface MemberExpressionNode extends BaseNode {
  type: 'memberExpression';
  object: ASTNode;
  property: ASTNode;
  computed: boolean;
}

export interface ProgramNode extends BaseNode {
  type: 'program';
  statements: ASTNode[];
}

export type ASTNode =
  | NumberNode
  | BinaryNode
  | PrintNode
  | GroupNode
  | VarDeclarationNode
  | IdentifierNode
  | AssignmentNode
  | ComparisonNode
  | IfNode
  | BlockNode
  | FunctionDeclarationNode
  | FunctionCallNode
  | ReturnNode
  | ArrayExpressionNode
  | MemberExpressionNode
  | ProgramNode;
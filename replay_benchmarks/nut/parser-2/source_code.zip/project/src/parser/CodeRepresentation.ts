export class CodeRepresentation {
  private code: string;
  private lines: string[];
  private lineStarts: number[];

  constructor(code: string) {
    this.code = code;
    this.lines = code.split('\n');
    this.lineStarts = this.calculateLineStarts();
  }

  private calculateLineStarts(): number[] {
    const starts: number[] = [0];
    let pos = 0;
    
    for (let i = 0; i < this.lines.length; i++) {
      pos += this.lines[i].length + 1; // +1 for newline
      starts.push(pos);
    }
    
    return starts;
  }

  getLineAndColumn(position: number): { line: number; column: number } {
    let line = 0;
    while (line < this.lineStarts.length - 1 && position >= this.lineStarts[line + 1]) {
      line++;
    }
    const column = position - this.lineStarts[line];
    return { line, column }; // Keep line 0-based
  }

  getAnnotatedLine(position: number): string {
    const { line, column } = this.getLineAndColumn(position);
    const lineContent = this.lines[line]; // Use 0-based line numbers
    if (!lineContent) return '';
    
    // Ensure column doesn't exceed line length
    const safeColumn = Math.min(column, lineContent.length);
    return lineContent.slice(0, safeColumn) + '<HEAD>' + lineContent.slice(safeColumn);
  }

  getCurrentLine(position: number): string {
    const { line } = this.getLineAndColumn(position);
    return this.lines[line] || ''; // Use 0-based line numbers
  }

  getLastPosition(): number {
    return this.code.length;
  }
}
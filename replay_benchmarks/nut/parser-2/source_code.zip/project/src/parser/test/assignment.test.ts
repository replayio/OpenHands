import { describe, test, expect } from 'vitest';
import { parse } from './utils';

describe('Variable Assignment', () => {
  test('parses simple assignment', () => {
    const ast = parse('var x = 1;\nx = 2');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'varDeclaration',
          name: 'x',
          initializer: { type: 'number', value: 1 }
        },
        {
          type: 'assignment',
          name: 'x',
          value: { type: 'number', value: 2 }
        }
      ]
    });
  });

  test('parses assignment with expression', () => {
    const ast = parse('var x = 1;\nx = 2 + 3');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'varDeclaration',
          name: 'x',
          initializer: { type: 'number', value: 1 }
        },
        {
          type: 'assignment',
          name: 'x',
          value: {
            type: 'addition',
            left: { type: 'number', value: 2 },
            right: { type: 'number', value: 3 }
          }
        }
      ]
    });
  });

  test('throws on assignment to undefined variable', () => {
    expect(() => parse('x = 1')).toThrow('Cannot assign to undefined variable: x');
  });

  test('parses assignment with complex expression', () => {
    const ast = parse('var x = 1;\nvar y = 2;\nx = y * 3');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'varDeclaration',
          name: 'x',
          initializer: { type: 'number', value: 1 }
        },
        {
          type: 'varDeclaration',
          name: 'y',
          initializer: { type: 'number', value: 2 }
        },
        {
          type: 'assignment',
          name: 'x',
          value: {
            type: 'multiplication',
            left: { type: 'identifier', name: 'y' },
            right: { type: 'number', value: 3 }
          }
        }
      ]
    });
  });
});
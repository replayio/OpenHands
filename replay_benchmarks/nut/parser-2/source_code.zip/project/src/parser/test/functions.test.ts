import { describe, test, expect } from 'vitest';
import { parse } from './utils';

describe('Function Declarations and Calls', () => {
  test('parses simple function declaration', () => {
    const ast = parse('function add(x, y) { return x + y }');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'functionDeclaration',
        name: 'add',
        params: ['x', 'y'],
        body: {
          type: 'block',
          statements: [{
            type: 'return',
            argument: {
              type: 'addition',
              left: { type: 'identifier', name: 'x' },
              right: { type: 'identifier', name: 'y' }
            }
          }]
        }
      }]
    });
  });

  test('parses function call', () => {
    const ast = parse('function add(x, y) { return x + y }\nprint add(1, 2)');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'functionDeclaration',
          name: 'add',
          params: ['x', 'y'],
          body: {
            type: 'block',
            statements: [{
              type: 'return',
              argument: {
                type: 'addition',
                left: { type: 'identifier', name: 'x' },
                right: { type: 'identifier', name: 'y' }
              }
            }]
          }
        },
        {
          type: 'print',
          argument: {
            type: 'functionCall',
            callee: 'add',
            arguments: [
              { type: 'number', value: 1 },
              { type: 'number', value: 2 }
            ]
          }
        }
      ]
    });
  });

  test('throws on undefined function call', () => {
    expect(() => parse('print add(1, 2)')).toThrow('Undefined function: add');
  });

  test('parses function with no parameters', () => {
    const ast = parse('function greet() { print 42 }');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'functionDeclaration',
        name: 'greet',
        params: [],
        body: {
          type: 'block',
          statements: [{
            type: 'print',
            argument: { type: 'number', value: 42 }
          }]
        }
      }]
    });
  });

  test('parses function with empty return', () => {
    const ast = parse('function empty() { return }');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'functionDeclaration',
        name: 'empty',
        params: [],
        body: {
          type: 'block',
          statements: [{
            type: 'return',
            argument: null
          }]
        }
      }]
    });
  });

  test('parses function with multiple statements', () => {
    const ast = parse('function calc(x) {\n  var y = x * 2;\n  return y + 1\n}');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'functionDeclaration',
        name: 'calc',
        params: ['x'],
        body: {
          type: 'block',
          statements: [
            {
              type: 'varDeclaration',
              name: 'y',
              initializer: {
                type: 'multiplication',
                left: { type: 'identifier', name: 'x' },
                right: { type: 'number', value: 2 }
              }
            },
            {
              type: 'return',
              argument: {
                type: 'addition',
                left: { type: 'identifier', name: 'y' },
                right: { type: 'number', value: 1 }
              }
            }
          ]
        }
      }]
    });
  });

  test('parses function call with variable arguments', () => {
    const ast = parse('function add(x, y) { return x + y }\nvar a = 5;\nvar b = 3;\nprint add(a, b)');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'functionDeclaration',
          name: 'add',
          params: ['x', 'y'],
          body: {
            type: 'block',
            statements: [{
              type: 'return',
              argument: {
                type: 'addition',
                left: { type: 'identifier', name: 'x' },
                right: { type: 'identifier', name: 'y' }
              }
            }]
          }
        },
        {
          type: 'varDeclaration',
          name: 'a',
          initializer: { type: 'number', value: 5 }
        },
        {
          type: 'varDeclaration',
          name: 'b',
          initializer: { type: 'number', value: 3 }
        },
        {
          type: 'print',
          argument: {
            type: 'functionCall',
            callee: 'add',
            arguments: [
              { type: 'identifier', name: 'a' },
              { type: 'identifier', name: 'b' }
            ]
          }
        }
      ]
    });
  });

  test('parses nested function calls', () => {
    const ast = parse('function double(x) { return x * 2 }\nfunction quad(x) { return double(double(x)) }');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'functionDeclaration',
          name: 'double',
          params: ['x'],
          body: {
            type: 'block',
            statements: [{
              type: 'return',
              argument: {
                type: 'multiplication',
                left: { type: 'identifier', name: 'x' },
                right: { type: 'number', value: 2 }
              }
            }]
          }
        },
        {
          type: 'functionDeclaration',
          name: 'quad',
          params: ['x'],
          body: {
            type: 'block',
            statements: [{
              type: 'return',
              argument: {
                type: 'functionCall',
                callee: 'double',
                arguments: [{
                  type: 'functionCall',
                  callee: 'double',
                  arguments: [{ type: 'identifier', name: 'x' }]
                }]
              }
            }]
          }
        }
      ]
    });
  });
});
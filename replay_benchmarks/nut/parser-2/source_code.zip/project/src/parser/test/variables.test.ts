import { describe, test, expect } from 'vitest';
import { parse } from './utils';

describe('Variable Declarations and Usage', () => {
  test('parses variable declaration with number', () => {
    const ast = parse('var x = 42');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'varDeclaration',
        name: 'x',
        initializer: { type: 'number', value: 42 }
      }]
    });
  });

  test('parses variable declaration with expression', () => {
    const ast = parse('var y = 2 * 3');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'varDeclaration',
        name: 'y',
        initializer: {
          type: 'multiplication',
          left: { type: 'number', value: 2 },
          right: { type: 'number', value: 3 }
        }
      }]
    });
  });

  test('parses variable usage in expressions', () => {
    const ast = parse('var x = 5;\nprint x + x');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'varDeclaration',
          name: 'x',
          initializer: { type: 'number', value: 5 }
        },
        {
          type: 'print',
          argument: {
            type: 'addition',
            left: { type: 'identifier', name: 'x' },
            right: { type: 'identifier', name: 'x' }
          }
        }
      ]
    });
  });

  test('throws on undefined variable', () => {
    expect(() => parse('print x')).toThrow('Undefined variable: x');
  });

  test('parses multiple variable declarations', () => {
    const ast = parse('var a = 1;\nvar b = 2;\nprint a + b');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'varDeclaration',
          name: 'a',
          initializer: { type: 'number', value: 1 }
        },
        {
          type: 'varDeclaration',
          name: 'b',
          initializer: { type: 'number', value: 2 }
        },
        {
          type: 'print',
          argument: {
            type: 'addition',
            left: { type: 'identifier', name: 'a' },
            right: { type: 'identifier', name: 'b' }
          }
        }
      ]
    });
  });

  test('parses complex expressions with variables', () => {
    const ast = parse('var x = 1 + 2;\nprint x * x');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'varDeclaration',
          name: 'x',
          initializer: {
            type: 'addition',
            left: { type: 'number', value: 1 },
            right: { type: 'number', value: 2 }
          }
        },
        {
          type: 'print',
          argument: {
            type: 'multiplication',
            left: { type: 'identifier', name: 'x' },
            right: { type: 'identifier', name: 'x' }
          }
        }
      ]
    });
  });
});
import { describe, test, expect } from 'vitest';
import { Parser } from '../parser';
import { tokenize } from '../tokenizer';
import { parse } from './utils';

describe('Multiple Statements', () => {
  test('parses multiple statements separated by semicolon', () => {
    const ast = parse('print 1; print 2');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        { type: 'print', argument: { type: 'number', value: 1 } },
        { type: 'print', argument: { type: 'number', value: 2 } }
      ]
    });
  });

  test('parses multiple statements separated by newline', () => {
    const ast = parse('print 1\nprint 2');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        { type: 'print', argument: { type: 'number', value: 1 } },
        { type: 'print', argument: { type: 'number', value: 2 } }
      ]
    });
  });

  test('parses mixed statement separators', () => {
    const ast = parse('print 1;\nprint 2; print 3');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        { type: 'print', argument: { type: 'number', value: 1 } },
        { type: 'print', argument: { type: 'number', value: 2 } },
        { type: 'print', argument: { type: 'number', value: 3 } }
      ]
    });
  });

  test('parses expressions and print statements together', () => {
    const ast = parse('1 + 2; print 3\n4 * 5');
    expect(ast).toEqual({
      type: 'program',
      statements: [
        {
          type: 'addition',
          left: { type: 'number', value: 1 },
          right: { type: 'number', value: 2 }
        },
        { type: 'print', argument: { type: 'number', value: 3 } },
        {
          type: 'multiplication',
          left: { type: 'number', value: 4 },
          right: { type: 'number', value: 5 }
        }
      ]
    });
  });
});
import { describe, test, expect } from 'vitest';
import { Parser } from '../parser';
import { tokenize } from '../tokenizer';
import { parse } from './utils';

describe('Error Cases', () => {
  test('throws on incomplete input', () => {
    expect(() => parse('print')).toThrow();
    expect(() => parse('print +')).toThrow();
    expect(() => parse('1 +')).toThrow();
  });

  test('throws on invalid statement separation', () => {
    expect(() => parse('print 1 print 2')).toThrow();
    expect(() => parse('1 + + 2')).toThrow();
  });
});
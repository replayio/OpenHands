import { describe, test, expect } from 'vitest';
import { Parser } from '../parser';
import { tokenize } from '../tokenizer';
import { parse } from './utils';

describe('Print Statements', () => {
  test('parses print with single number', () => {
    const ast = parse('print 1');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'print',
        argument: { type: 'number', value: 1 }
      }]
    });
  });

  test('parses print with multiplication', () => {
    const ast = parse('print 2 * 3');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'print',
        argument: {
          type: 'multiplication',
          left: { type: 'number', value: 2 },
          right: { type: 'number', value: 3 }
        }
      }]
    });
  });

  test('parses print with addition', () => {
    const ast = parse('print 1 + 2');
    expect(ast).toEqual({
      type: 'program',
      statements: [{
        type: 'print',
        argument: {
          type: 'addition',
          left: { type: 'number', value: 1 },
          right: { type: 'number', value: 2 }
        }
      }]
    });
  });
});
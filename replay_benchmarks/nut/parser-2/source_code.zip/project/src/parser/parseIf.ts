import { IfNode, ParserContext, ASTNode } from './types';
import { peek, consume } from './parserUtils';
import { parseComparison } from './parseComparison';
import { parseBlock } from './parseBlock';

export function parseIf(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): IfNode {
  const token = peek(context);
  if (!token || token.type !== 'if') {
    throw new Error('Expected if keyword');
  }
  consume(context); // consume 'if'

  // Expect opening parenthesis
  const openParen = peek(context);
  if (!openParen || openParen.type !== 'paren' || openParen.value !== '(') {
    throw new Error("Expected '(' after if");
  }
  consume(context);

  // Parse condition
  const condition = parseComparison(context, onStep);

  // Expect closing parenthesis
  const closeParen = peek(context);
  if (!closeParen || closeParen.type !== 'paren' || closeParen.value !== ')') {
    throw new Error("Expected ')' after condition");
  }
  consume(context);

  // Parse block
  const consequent = parseBlock(context, onStep);

  const node: IfNode = {
    type: 'if',
    condition,
    consequent
  };

  onStep('If', node);
  return node;
}
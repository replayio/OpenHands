import { ReturnNode, ParserContext, ASTNode } from './types';
import { peek, consume } from './parserUtils';
import { parseExpression } from './parseExpression';

export function parseReturn(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): ReturnNode {
  onStep('Return: Start', null);

  // Consume 'return' keyword
  consume(context);

  // Check if there's an expression after return
  const token = peek(context);
  let argument: ASTNode | null = null;

  if (token && token.type !== 'separator' && token.type !== 'brace') {
    onStep('Return: Parsing Expression', null);
    argument = parseExpression(context, onStep);
  }

  const node: ReturnNode = {
    type: 'return',
    argument
  };

  onStep('Return: Complete', node);
  return node;
}
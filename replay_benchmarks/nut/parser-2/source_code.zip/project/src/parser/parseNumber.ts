import { NumberNode, ParserContext, ASTNode } from './types';
import { peek, consume } from './parserUtils';

export function parseNumber(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): NumberNode {
  const token = peek(context);
  
  if (!token || token.type !== 'number') {
    throw new Error(`Expected number, got ${token?.type || 'end of input'}`);
  }

  const node: NumberNode = {
    type: 'number',
    value: parseFloat(token.value)
  };

  consume(context);
  onStep('Number', node);
  return node;
}
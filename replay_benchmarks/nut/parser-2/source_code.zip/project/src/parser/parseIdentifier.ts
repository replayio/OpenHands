import { IdentifierNode, ParserContext, ASTNode } from './types';
import { peek, consume, isVariableInScope } from './parserUtils';
import { parseFunctionCall } from './parseFunctionCall';

export function parseIdentifier(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): ASTNode {
  const token = peek(context);
  
  if (!token || token.type !== 'identifier') {
    throw new Error(`Expected identifier, got ${token?.type || 'end of input'}`);
  }

  // Look ahead to see if this is a function call
  const nextToken = context.tokens[context.current + 1];
  if (nextToken?.type === 'paren' && nextToken.value === '(') {
    if (!context.functions.has(token.value)) {
      throw new Error(`Undefined function: ${token.value}`);
    }
    return parseFunctionCall(context, onStep);
  }

  // Not a function call, treat as variable
  if (!isVariableInScope(context.currentScope, token.value)) {
    throw new Error(`Undefined variable: ${token.value}`);
  }

  const node: IdentifierNode = {
    type: 'identifier',
    name: token.value
  };

  consume(context);
  onStep('Identifier', node);
  return node;
}
import { ASTNode, ParserContext } from './types';
import { peek, consume } from './parserUtils';
import { parseFactor } from './parseFactor';

export function parseTerm(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): ASTNode {
  let node = parseFactor(context, onStep);
  
  while (peek(context)?.type === 'operator' && peek(context)?.value === '*') {
    const operator = peek(context)!;
    consume(context); // consume operator
    const right = parseFactor(context, onStep);
    
    node = {
      type: 'multiplication',
      left: node,
      right
    };
    onStep('Multiplication', node);
  }
  
  return node;
}
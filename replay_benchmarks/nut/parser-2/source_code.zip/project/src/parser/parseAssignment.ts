import { AssignmentNode, ParserContext, ASTNode } from './types';
import { peek, consume, isVariableInScope } from './parserUtils';
import { parseExpression } from './parseExpression';
import { parseMemberExpression } from './parseMemberExpression';

export function parseAssignment(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): AssignmentNode {
  onStep('Assignment: Start', null);

  const identifier = peek(context);
  if (!identifier || identifier.type !== 'identifier') {
    throw new Error('Expected identifier');
  }

  // Check if variable exists
  if (!isVariableInScope(context.currentScope, identifier.value)) {
    throw new Error(`Cannot assign to undefined variable: ${identifier.value}`);
  }

  let target: ASTNode = {
    type: 'identifier',
    name: identifier.value
  };
  consume(context); // consume identifier

  // Handle array indexing in assignment target
  while (peek(context)?.type === 'bracket' || peek(context)?.type === 'dot') {
    target = parseMemberExpression(context, target, onStep);
  }

  const equals = peek(context);
  if (!equals || equals.type !== 'equals') {
    throw new Error('Expected = in assignment');
  }
  consume(context); // consume equals

  const value = parseExpression(context, onStep);

  const node: AssignmentNode = {
    type: 'assignment',
    target,
    value
  };

  onStep('Assignment: Complete', node);
  return node;
}
import { ASTNode, ParserContext } from './types';
import { peek, consume } from './parserUtils';
import { parseTerm } from './parseTerm';

export function parseExpression(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): ASTNode {
  let node = parseTerm(context, onStep);
  
  while (peek(context)?.type === 'operator' && ['+', '-'].includes(peek(context)?.value || '')) {
    const operator = peek(context)!;
    consume(context); // consume operator
    const right = parseTerm(context, onStep);
    
    node = {
      type: operator.value === '+' ? 'addition' : 'subtraction',
      left: node,
      right
    };
    onStep(operator.value === '+' ? 'Addition' : 'Subtraction', node);
  }
  
  return node;
}
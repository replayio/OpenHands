import { ASTNode, ParserContext, ProgramNode, Token } from './types';
import { parseStatement } from './parseStatement';
import { peek, consume, createScope } from './parserUtils';

export function parseProgram(
  tokens: Token[], 
  current: number, 
  onStep: (nodeName: string, node: ASTNode | null) => void
): ProgramNode {
  const programNode: ProgramNode = {
    type: 'program',
    statements: []
  };

  const context: ParserContext = {
    tokens,
    current,
    ast: programNode,
    parsingPhase: 'statement',
    currentScope: createScope(),
    functions: new Set()
  };

  // Always emit initial program state
  onStep('Program: Start', programNode);

  while (context.current < tokens.length) {
    // Skip separators between statements
    while (peek(context)?.type === 'separator') {
      consume(context);
    }

    // Break if we've reached the end
    if (context.current >= tokens.length) break;

    const statement = parseStatement(context, onStep);
    programNode.statements.push(statement);
    
    // Emit state after each statement is added
    onStep('Program: Statement Added', structuredClone(programNode));

    // Require a separator between statements unless we're at the end
    if (context.current < tokens.length) {
      const nextToken = peek(context);
      if (!nextToken || nextToken.type !== 'separator') {
        throw new Error('Expected statement separator');
      }
      consume(context); // consume the separator
    }
  }

  // Always emit final program state
  onStep('Program: Complete', programNode);
  return programNode;
}
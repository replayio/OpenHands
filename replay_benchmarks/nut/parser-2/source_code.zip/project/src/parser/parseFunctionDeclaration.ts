import { FunctionDeclarationNode, ParserContext, ASTNode } from './types';
import { peek, consume, createScope, addVariableToScope } from './parserUtils';
import { parseBlock } from './parseBlock';

export function parseFunctionDeclaration(context: ParserContext, onStep: (nodeName: string, node: ASTNode | null) => void): FunctionDeclarationNode {
  onStep('Function Declaration: Start', null);

  // Consume 'function' keyword
  consume(context);

  // Get function name
  const identifier = peek(context);
  if (!identifier || identifier.type !== 'identifier') {
    throw new Error('Expected function name');
  }
  const functionName = identifier.value;
  consume(context);

  // Add to functions set
  context.functions.add(functionName);

  const partialNode: FunctionDeclarationNode = {
    type: 'functionDeclaration',
    name: functionName,
    params: [],
    body: { type: 'block', statements: [] }
  };

  onStep('Function Declaration: Name', partialNode);

  // Expect opening parenthesis
  const openParen = peek(context);
  if (!openParen || openParen.type !== 'paren' || openParen.value !== '(') {
    throw new Error('Expected ( after function name');
  }
  consume(context);

  onStep('Function Declaration: Parameters Start', partialNode);

  // Create new scope for function parameters and body
  const functionScope = createScope(context.currentScope);
  const previousScope = context.currentScope;
  context.currentScope = functionScope;

  // Parse parameters
  while (context.current < context.tokens.length) {
    const token = peek(context);
    if (!token) break;

    if (token.type === 'paren' && token.value === ')') {
      consume(context);
      break;
    }

    if (token.type === 'comma') {
      consume(context);
      continue;
    }

    if (token.type !== 'identifier') {
      throw new Error('Expected parameter name');
    }

    partialNode.params.push(token.value);
    addVariableToScope(functionScope, token.value);
    consume(context);

    onStep(`Function Declaration: Parameter "${token.value}"`, structuredClone(partialNode));
  }

  onStep('Function Declaration: Parameters Complete', structuredClone(partialNode));

  // Parse function body
  onStep('Function Declaration: Body Start', structuredClone(partialNode));
  
  const body = parseBlock(context, (nodeName, node) => {
    if (node) {
      partialNode.body = node;
      onStep(`Function Body: ${nodeName}`, structuredClone(partialNode));
    } else {
      onStep(`Function Body: ${nodeName}`, null);
    }
  });
  
  partialNode.body = body;

  // Restore previous scope
  context.currentScope = previousScope;

  onStep('Function Declaration: Complete', structuredClone(partialNode));
  return partialNode;
}